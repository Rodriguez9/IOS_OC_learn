//
//  AppDelegate.h
//  RXBookRead
//
//  Created by Evan on 2018/5/28.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GDTSplashAd.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate,GDTSplashAdDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) GDTSplashAd *splash;

@end

