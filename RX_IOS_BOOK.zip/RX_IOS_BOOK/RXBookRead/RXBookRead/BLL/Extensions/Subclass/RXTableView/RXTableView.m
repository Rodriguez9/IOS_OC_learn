//
//  RXTableView.m
//  RXBookRead
//
//  Created by Evan on 2018/5/30.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXTableView.h"

@implementation RXTableView

- (instancetype)initWithFrame:(CGRect)frame style:(UITableViewStyle)style {
    if (self = [super initWithFrame:frame style:style]) {
        [self setTableFooterView:[UIView new]];
        
        self.estimatedRowHeight = 0;
        self.estimatedSectionHeaderHeight = 0;
        self.estimatedSectionFooterHeight = 0;
        [self setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    }
    return self;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    [self endEditing:YES];
}
@end
