//
//  RXNavigationController.m
//  RXBookRead
//
//  Created by Evan on 2018/5/29.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXNavigationController.h"

@interface RXNavigationController ()

@end

@implementation RXNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];

    // 主题
    [self.navigationBar setBarTintColor:RXColor(200, 10, 10, 1.0)];
    [self.navigationBar setTintColor:[UIColor whiteColor]];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [[UINavigationBar appearance] setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor],NSFontAttributeName:[UIFont systemFontOfSize:16]}];
}



@end
