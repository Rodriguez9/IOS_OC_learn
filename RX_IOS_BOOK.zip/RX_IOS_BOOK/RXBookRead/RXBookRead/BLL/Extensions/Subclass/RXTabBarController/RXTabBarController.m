//
//  RXTabBarController.m
//  RXBookRead
//
//  Created by Evan on 2018/5/29.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXTabBarController.h"
#import "RXNavigationController.h"
#import "RXBookshelfController.h"
#import "RXLeaderboardController.h"
#import "RXSearchController.h"
#import "RXCategoryController.h"
#import "RXMoreController.h"


@interface RXTabBarController ()
@property (nonatomic, strong) NSArray *childVCArray;
@property (nonatomic, strong) RXBookshelfController *bookshelfVC;
@property (nonatomic, strong) RXLeaderboardController *leaderBoardVC;
@property (nonatomic, strong) RXCategoryController *categoryVC;
@property (nonatomic, strong) RXSearchController *searchVC;
@property (nonatomic, strong) RXMoreController *moreVC;
@end

@implementation RXTabBarController


- (void)viewDidLoad{
    
    [super viewDidLoad];
    
    self.tabBar.hidden = YES;
    self.tabBar.tintColor = RXColor(200, 10, 10, 1.0);
    self.viewControllers = self.childVCArray;
}

#pragma mark - Getters
- (NSArray *) childVCArray
{
    if (_childVCArray == nil) {
        //书架
        RXNavigationController *bookshelfNavC = [[RXNavigationController alloc] initWithRootViewController:self.bookshelfVC];
        bookshelfNavC.navigationBarHidden = YES;
        //排行榜
        RXNavigationController *leaderBoardNavC = [[RXNavigationController alloc] initWithRootViewController:self.leaderBoardVC];
        //分类
        RXNavigationController *categoryNavC = [[RXNavigationController alloc]initWithRootViewController:self.categoryVC];
        //更多
        RXNavigationController *moreNavC = [[RXNavigationController alloc]initWithRootViewController:self.moreVC];
        
        _childVCArray = @[bookshelfNavC, leaderBoardNavC,categoryNavC,moreNavC];
    }
    return _childVCArray;
}

- (RXBookshelfController *)bookshelfVC
{
    if (_bookshelfVC == nil) {
        _bookshelfVC = [[RXBookshelfController alloc] init];
        [_bookshelfVC.view setBackgroundColor:[UIColor whiteColor]];
        [_bookshelfVC.tabBarItem setTitle:@"书架"];
        [_bookshelfVC.tabBarItem setImage:[UIImage imageNamed:@"Tabbar_bookShelf_Normal"]];
        [_bookshelfVC.tabBarItem setSelectedImage:[UIImage imageNamed:@"Tabbar_bookShelf_Highlighted"]];
    }
    return _bookshelfVC;
}

- (RXLeaderboardController *)leaderBoardVC{
    if (_leaderBoardVC == nil) {
        _leaderBoardVC = [[RXLeaderboardController alloc] init];
        [_leaderBoardVC.view setBackgroundColor:[UIColor whiteColor]];
        [_leaderBoardVC.tabBarItem setTitle:@"排行榜"];
        [_leaderBoardVC.tabBarItem setImage:[UIImage imageNamed:@"Tabbar_leaderboard_Normal"]];
        [_leaderBoardVC.tabBarItem setSelectedImage:[UIImage imageNamed:@"Tabbar_leaderboard_Highlighted"]];
    }
    return _leaderBoardVC;
}

- (RXCategoryController *)categoryVC{
    if (_categoryVC == nil) {
        _categoryVC = [[RXCategoryController alloc] init];
        [_categoryVC.view setBackgroundColor:[UIColor whiteColor]];
        [_categoryVC.tabBarItem setTitle:@"分类"];
        [_categoryVC.tabBarItem setImage:[UIImage imageNamed:@"Tabbar_categoty_Normal"]];
        [_categoryVC.tabBarItem setSelectedImage:[UIImage imageNamed:@"Tabbar_category_Highlighted"]];
    }
    return _categoryVC;
}

- (RXSearchController *)searchVC{
    if (_searchVC == nil) {
        _searchVC = [[RXSearchController alloc] init];
        [_searchVC.view setBackgroundColor:[UIColor whiteColor]];
        [_searchVC.tabBarItem setTitle:@"搜索"];
        [_searchVC.tabBarItem setImage:[UIImage imageNamed:@"Tabbar Message Normal"]];
        [_searchVC.tabBarItem setSelectedImage:[UIImage imageNamed:@"Tabbar Message Highlighted"]];
    }
    return _searchVC;
}

- (RXMoreController *)moreVC{
    if (_moreVC == nil) {
        _moreVC = [[RXMoreController alloc] init];
        [_moreVC.view setBackgroundColor:[UIColor whiteColor]];
        [_moreVC.tabBarItem setTitle:@"更多"];
        [_moreVC.tabBarItem setImage:[UIImage imageNamed:@"Tabbar_more_Normal"]];
        [_moreVC.tabBarItem setSelectedImage:[UIImage imageNamed:@"Tabbar_more_Highlighted"]];
    }
    return _moreVC;
}
@end
