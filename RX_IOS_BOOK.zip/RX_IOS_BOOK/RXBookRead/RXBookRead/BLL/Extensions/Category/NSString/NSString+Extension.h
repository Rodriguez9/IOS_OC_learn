//
//  NSString+Extension.h
//  RXBookRead
//
//  Created by Evan on 2018/5/30.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Extension)

- (NSArray *)compomentString;

+ (NSString *)MD5:(NSString *)str;
@end
