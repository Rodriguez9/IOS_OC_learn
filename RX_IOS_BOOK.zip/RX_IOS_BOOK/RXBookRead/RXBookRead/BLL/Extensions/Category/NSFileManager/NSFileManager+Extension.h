//
//  NSFileManager+Extension.h
//  RXBookRead
//
//  Created by Evan on 2018/6/8.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSFileManager (Extension)
+ (NSString *)pathForReadChapterJsonCache:(NSString *)bookId name:(NSString *)name;


+ (NSString *)pathForBookShelfWithName:(NSString *)name;
@end
