//
//  NSFileManager+Extension.m
//  RXBookRead
//
//  Created by Evan on 2018/6/8.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "NSFileManager+Extension.h"

@implementation NSFileManager (Extension)

+ (NSString *)pathForReadChapterJsonCache:(NSString *)bookId name:(NSString *)name{
     NSString *path = [NSString stringWithFormat:@"%@/User/JSON/%@/", RXDocumentDirectory,bookId];
     [self createPath:path];
    return [path stringByAppendingString:name];
}

+ (NSString *)pathForBookShelfWithName:(NSString *)name{
    NSString *path = [NSString stringWithFormat:@"%@/User/JSON/", RXDocumentDirectory];
    [self createPath:path];
    return [path stringByAppendingString:name];
}
#pragma mark - private
+ (void)createPath:(NSString *)path {
    if (![[NSFileManager defaultManager] fileExistsAtPath:path]) {
        NSError *error;
        [[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:&error];
        if (error) {
            RXLog(@"File Create Failed: %@", path);
        }
    }
}

@end
