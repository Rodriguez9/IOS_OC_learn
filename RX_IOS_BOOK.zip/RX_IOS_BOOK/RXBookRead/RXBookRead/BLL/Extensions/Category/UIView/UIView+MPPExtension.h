//
//  UIView+MPPExtension.h
//  EWuApp
//
//  Created by MPP on 16/5/8.
//  Copyright © 2016年 MPP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (MPPExtension)

/** 在分类中声明@property, 只会生成方法（get,set）的声明, 不会生成方法的实现和带有_下划线的成员变量*/

/** x */
@property (nonatomic, assign) CGFloat mp_x;
/** y */
@property (nonatomic, assign) CGFloat mp_y;
/** 宽度 */
@property (nonatomic, assign) CGFloat mp_width;
/** 高度 */
@property (nonatomic, assign) CGFloat mp_height;
/** 原点 */
@property (nonatomic, assign) CGPoint mp_origin;
/** 尺寸 */
@property (nonatomic, assign) CGSize mp_size;
/** 中心点x */
@property (nonatomic, assign) CGFloat mp_centerX;
/** 中心点y */
@property (nonatomic, assign) CGFloat mp_centerY;

/** 判断一个控件是否真正显示在主窗口 */
- (BOOL)isShowingOnKeyWindow;

/**
 * 从xib中加载view（xib的名字要和类名一直，并且只取第一个view）
 */
+ (instancetype)viewFromXib;

@end
