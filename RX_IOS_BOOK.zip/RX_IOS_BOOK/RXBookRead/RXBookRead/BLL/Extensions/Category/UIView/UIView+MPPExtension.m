//
//  UIView+MPPExtension.m
//  EWuApp
//
//  Created by MPP on 16/5/8.
//  Copyright © 2016年 MPP. All rights reserved.
//

#import "UIView+MPPExtension.h"

@implementation UIView (MPPExtension)
//@dynamic mp_x,mp_y,mp_size,mp_width,mp_height,mp_centerX,mp_centerY;

- (CGFloat)mp_x
{
    return self.frame.origin.x;
}

- (CGFloat)mp_y
{
    return self.frame.origin.y;
}

- (CGFloat)mp_centerX
{
    return self.center.x;
}

- (CGFloat)mp_centerY
{
    return self.center.y;
}

- (CGFloat)mp_width
{
    return self.frame.size.width;
}

- (CGFloat)mp_height
{
    return self.frame.size.height;
}

- (CGPoint)mp_origin
{
    return self.frame.origin;
}

- (CGSize)mp_size
{
    return self.frame.size;
}


#pragma mark -


- (void)setMp_x:(CGFloat)mp_x
{
    CGRect r = self.frame;
    r.origin.x = mp_x;
    self.frame = r;
}
- (void)setMp_y:(CGFloat)mp_y
{
    CGRect r = self.frame;
    r.origin.y = mp_y;
    self.frame = r;
}
- (void)setMp_centerX:(CGFloat)mp_centerX
{
    CGPoint center = self.center;
    center.x = mp_centerX;
    self.center = center;
}
- (void)setMp_centerY:(CGFloat)mp_centerY
{
    CGPoint center = self.center;
    center.y = mp_centerY;
    self.center = center;
}
- (void)setMp_width:(CGFloat)mp_width
{
    CGRect r = self.frame;
    r.size.width = mp_width;
    self.frame = r;
}
- (void)setMp_height:(CGFloat)mp_height
{
    CGRect r = self.frame;
    r.size.height = mp_height;
    self.frame = r;
}

- (void)setMp_origin:(CGPoint)mp_origin
{
    CGRect r = self.frame;
    r.origin = mp_origin;
    self.frame = r;
}

- (void)setMp_size:(CGSize)mp_size
{
    CGRect r = self.frame;
    r.size = mp_size;
    self.frame = r;
}

#pragma mark -
#pragma mark -

- (BOOL)isShowingOnKeyWindow
{
    // 主窗口
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    
    // 以主窗口左上角为坐标原点, 计算self的矩形框
    CGRect newFrame = [keyWindow convertRect:self.frame fromView:self.superview];
    CGRect winBounds = keyWindow.bounds;
    
    // 主窗口的bounds 和 self的矩形框 是否有重叠
    BOOL intersects = CGRectIntersectsRect(newFrame, winBounds);
    
    return !self.isHidden && self.alpha > 0.01 && self.window == keyWindow && intersects;
}

+ (instancetype)viewFromXib{
    return [[[NSBundle mainBundle] loadNibNamed:NSStringFromClass(self) owner:nil options:nil] firstObject];
}
@end
