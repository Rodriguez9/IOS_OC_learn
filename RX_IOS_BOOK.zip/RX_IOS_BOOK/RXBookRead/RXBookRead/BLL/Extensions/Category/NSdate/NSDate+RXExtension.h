//
//  NSDate+RXExtension.h
//  RXBookRead
//
//  Created by Evan on 2018/5/31.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (RXExtension)
- (NSString *)bookDetailTimeInfo;
@end
