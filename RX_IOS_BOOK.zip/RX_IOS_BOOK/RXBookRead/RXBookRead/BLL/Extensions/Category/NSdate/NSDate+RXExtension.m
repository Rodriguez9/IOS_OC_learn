//
//  NSDate+RXExtension.m
//  RXBookRead
//
//  Created by Evan on 2018/5/31.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "NSDate+RXExtension.h"
#import "NSDate+Utilities.h"
#import "NSDate+Extension.h"

@implementation NSDate (RXExtension)

- (NSString *)bookDetailTimeInfo{
    if ([self isToday]) {                       // 今天
        return self.formatHM;
    }
    else if ([self isYesterday]) {              // 昨天
        return @"昨天";
    }
    else if ([self isTheDayBeforeYesterday]){   // 前天
        return @"前天";
    }
    else if ([self isThisWeek]){  //本周
        return @"本周内";
    }else{
        return self.formatYMD;
    }
    return nil;
}
@end
