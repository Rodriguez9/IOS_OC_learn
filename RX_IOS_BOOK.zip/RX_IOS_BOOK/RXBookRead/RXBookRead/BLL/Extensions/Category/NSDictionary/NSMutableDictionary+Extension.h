//
//  NSMutableDictionary+Extension.h
//  RXBookRead
//
//  Created by Evan on 2018/5/29.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableDictionary (Extension)
- (void)rx_setObject:(id)object forKey:(id <NSCopying>)key;

- (void)rx_removeObjectForKey:(NSString *)key;
@end
