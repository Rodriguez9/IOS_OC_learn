//
//  NSMutableDictionary+Extension.m
//  RXBookRead
//
//  Created by Evan on 2018/5/29.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "NSMutableDictionary+Extension.h"

@implementation NSMutableDictionary (Extension)

- (void)rx_setObject:(id)object forKey:(id <NSCopying>)key {
    if (object && key) {
        [self setObject:object forKey:key];
    }
}

- (void)rx_removeObjectForKey:(NSString *)key {
    if (key) {
        [self removeObjectForKey:key];
    }
}
@end
