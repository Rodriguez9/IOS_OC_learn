//
//  NSMutableArray+Extension.h
//  RXBookRead
//
//  Created by Evan on 2018/5/29.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableArray (Extension)
- (void)rx_addObject:(id)object;


- (void)rx_insertObject:(id)anObject atIndex:(NSUInteger)index;


- (void)rx_removeObjectAtIndex:(NSUInteger)index;
@end
