//
//  NSMutableArray+Extension.m
//  RXBookRead
//
//  Created by Evan on 2018/5/29.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "NSMutableArray+Extension.h"

@implementation NSMutableArray (Extension)

- (void)rx_addObject:(id)object {
    if (object) {
        [self addObject:object];
    }
}

- (void)rx_insertObject:(id)anObject atIndex:(NSUInteger)index {
    if (anObject && index <= self.count) {
        [self insertObject:anObject atIndex:index];
    }
}


- (void)rx_removeObjectAtIndex:(NSUInteger)index {
    if (self.count > index) {
        [self removeObjectAtIndex:index];
    }
}

@end
