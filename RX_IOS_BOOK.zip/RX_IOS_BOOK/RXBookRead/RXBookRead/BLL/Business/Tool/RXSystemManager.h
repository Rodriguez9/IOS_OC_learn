//
//  RXSystemManager.h
//  RXBookRead
//
//  Created by Evan on 2018/5/29.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXObject.h"

@interface RXSystemManager : RXObject
/** 当前屏幕尺寸 */
+ (CGRect) screenRect;

//颜色装换
+ (UIColor *)colorWithHexString:(NSString *)stringToConvert;
@end
