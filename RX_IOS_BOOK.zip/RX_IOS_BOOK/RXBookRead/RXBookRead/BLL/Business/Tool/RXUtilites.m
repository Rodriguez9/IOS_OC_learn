//
//  RXUtilites.m
//  RXBookRead
//
//  Created by Evan on 2018/6/4.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXUtilites.h"
#import "RXChapterModel.h"
#import <AdSupport/AdSupport.h>
#import "RSAEncryptTool.h"

@implementation RXUtilites

+(UIButton *)commonButtonSEL:(SEL)sel target:(id)target
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button.titleLabel setFont:[UIFont systemFontOfSize:12]];
    [button setTintColor:[UIColor whiteColor]];
    [button addTarget:target action:sel forControlEvents:UIControlEventTouchUpInside];
    return button;
}

+(UIViewController *)getCurrentVC
{
    UIViewController *result = nil;
    
    
    UIWindow * window = [[UIApplication sharedApplication] keyWindow];
    if (window.windowLevel != UIWindowLevelNormal)
    {
        NSArray *windows = [[UIApplication sharedApplication] windows];
        for(UIWindow * tmpWin in windows)
        {
            if (tmpWin.windowLevel == UIWindowLevelNormal)
            {
                window = tmpWin;
                break;
            }
        }
    }
    
    
    UIView *frontView = [[window subviews] objectAtIndex:0];
    id nextResponder = [frontView nextResponder];
    
    
    if ([nextResponder isKindOfClass:[UIViewController class]])
        result = nextResponder;
    else
        result = window.rootViewController;
    
    return result;
}

//+ (NSInteger)getChapterWithLink:(NSString *)link{
//    if (![[link pathExtension] isEqualToString:@"txt"]) return 0;
//    NSString *str = [link substringFromIndex:link.length - 10];
//    NSRange range = [str rangeOfString:@"_"];
//    NSRange range1 = [str rangeOfString:@"."];
//    NSString *str1 = [str substringWithRange:NSMakeRange(range.location + 1, range1.location - range.location - 1)];
//    return [str1 integerValue];
//}


+ (BOOL)isThisChapterNeedDownLoad:(NSMutableArray *)chapter link:(NSString *)link{
    NSMutableArray *tempArray = [NSMutableArray array];
    for (RXChapterModel *model in chapter) {
        [tempArray addObject:model.link];
    }
    return ![tempArray containsObject:link];
}

+ (UIImage *)getBackgroundImage{
    UIImage *splashImage = [UIImage imageNamed:@"SplashNormal"];
    
    if (iPhone_X) {
        splashImage = [UIImage imageNamed:@"SplashX"];
    } else if (iPhone_5) {
        splashImage = [UIImage imageNamed:@"SplashSmall"];
    } else if (iPhone_7Plus){
        splashImage = [UIImage imageNamed:@"SplashP"];
    }
    
    
    return [UIImage imageResize:splashImage andResizeTo:SIZE_SCREEN];
}

+ (NSString *)getEncryptString{
    
    NSString *identifier = [ASIdentifierManager sharedManager].advertisingIdentifier.UUIDString;
    
    NSString *path = [[NSBundle mainBundle] pathForResource:@"public_key.der" ofType:nil];
    
    return [RSAEncryptTool encryptString:identifier publicKeyWithContentsOfFile:path];
}

+ (NSString *)getPreString:(NSString *)str{
    
    NSMutableString *newStr = [NSMutableString stringWithCapacity:str.length];
    
    [str enumerateSubstringsInRange:NSMakeRange(0, str.length) options:NSStringEnumerationReverse | NSStringEnumerationByComposedCharacterSequences  usingBlock:^(NSString *substring, NSRange substringRange, NSRange enclosingRange, BOOL *stop){
        if (![substring isEqualToString:@" "]) {
            [newStr appendString:substring];
        }
    }];
    
    return [[NSString stringWithFormat:@"%@",newStr] lowercaseString];
}

+ (BOOL)canOpenURL:(NSURL *)URL{
    return [[UIApplication sharedApplication] canOpenURL:URL];
}

+ (void)openURL:(NSURL *)URL{
    if (iOS10_OR_LATER) {
        [[UIApplication sharedApplication] openURL:URL options:@{UIApplicationOpenURLOptionUniversalLinksOnly: @NO} completionHandler:^(BOOL success) {
        }];
    }else{
        [[UIApplication sharedApplication] openURL:URL];
    }
}

+ (NSMutableURLRequest *)getRequest{
    NSURL *url = [NSURL URLWithString:@"https://play.rexueyouxi.com/gameinfo"];
    // 2.获取网络请求
    NSMutableURLRequest *mRequest = [NSMutableURLRequest requestWithURL:url];
    // 设置连接字符串
    NSTimeInterval time=[[NSDate date] timeIntervalSince1970];
    
    long timet = time;
    NSString *stime =  [NSString stringWithFormat:@"%ld",timet];   //NSTimeInterval返回的是double类型
    NSString *miyao = @"@Rq84^lE0mdZGq4gQvg!XnLmmATUU%wq";
    
    NSString *token = [NSString stringWithFormat:@"game_id=%@&pkg=%@&time=%@%@",APP_ID,IOS_VERSION,stime,miyao];
    
    NSString *config = [NSString MD5:token];//MD5加密后的字符串
    
    NSString *dataString = [NSString stringWithFormat:@"game_id=%@&pkg=%@&time=%@&config_token=%@",APP_ID,IOS_VERSION,stime,config];;
    // 转换格式
    NSData *postData = [dataString dataUsingEncoding:NSUTF8StringEncoding];
    // 设置请求类型
    [mRequest setHTTPMethod:@"POST"];
    // 设置请求体
    [mRequest setHTTPBody:postData];
    return mRequest;
}
@end
