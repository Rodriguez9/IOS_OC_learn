//
//  RXReadUtilites.h
//  RXBookRead
//
//  Created by Evan on 2018/6/5.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXObject.h"

@interface RXReadUtilites : RXObject
//缓存章节详情的数组
@property (nonatomic, strong) NSMutableArray *chapters;
//缓存章节列表的数组
@property (nonatomic, strong) NSMutableArray *chapterList;
+ (RXReadUtilites *)sharedInstance;
//保存已经阅读的书籍章节
+ (void)saveDownLoadedChapter:(NSString *)bookID preChapterDict:(NSMutableDictionary *)preChapterDict;
//获取书籍的阅读记录
+ (NSMutableDictionary *)getDownLoadedChapter:(NSString *)bookID;
//保存加入书架的书
+ (void)saveBookToShelfsBookWithBookArray:(NSMutableArray *)bookArray;
//取出加入书架的书
+ (NSMutableArray *)getBookshelfsBook;
- (void)resetInstance;
@end
