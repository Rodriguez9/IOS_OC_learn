//
//  RXUtilites.h
//  RXBookRead
//
//  Created by Evan on 2018/6/4.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXObject.h"

@interface RXUtilites : RXObject

+(UIButton *)commonButtonSEL:(SEL)sel target:(id)target;

+(UIViewController *)getCurrentVC;
////通过连接获取小说的第几章
//+ (NSInteger)getChapterWithLink:(NSString *)link;

//判断该章节有没有下载过
+ (BOOL)isThisChapterNeedDownLoad:(NSMutableArray *)chapter link:(NSString *)link;

+ (UIImage *)getBackgroundImage;

+ (NSString *)getEncryptString;

+ (NSString *)getPreString:(NSString *)str;

+ (BOOL)canOpenURL:(NSURL *)URL;

+ (void)openURL:(NSURL *)URL;

+ (NSMutableURLRequest *)getRequest;
@end
