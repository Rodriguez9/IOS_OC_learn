//
//  RXReadUtilites.m
//  RXBookRead
//
//  Created by Evan on 2018/6/5.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXReadUtilites.h"
#import "RXChapterListModel.h"
#import "RXChapterModel.h"
#import <MJExtension.h>
#import "RXBookDetailModel.h"

@implementation RXReadUtilites

+ (RXReadUtilites *)sharedInstance{
    static RXReadUtilites *tool;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        tool = [[RXReadUtilites alloc] init];
        
    });
    return tool;
}

- (NSMutableArray *)chapters{
    if (!_chapters) {
        _chapters = [NSMutableArray array];
    }
    return _chapters;
}

- (NSMutableArray *)chapterList{
    if (!_chapterList) {
        _chapterList = [NSMutableArray array];
    }
    return _chapterList;
}

+ (void)saveDownLoadedChapter:(NSString *)bookID preChapterDict:(NSMutableDictionary *)preChapterDict{
    NSString *path = [NSFileManager pathForReadChapterJsonCache:bookID name:@"book.json"];

    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:preChapterDict options:NSJSONWritingPrettyPrinted error:nil];
    
    NSString *fileString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
    
    [fileString writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
    
}

+ (NSMutableDictionary *)getDownLoadedChapter:(NSString *)bookID{
    NSString *path = [NSFileManager pathForReadChapterJsonCache:bookID name:@"book.json"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    if(data){
        id jsonObject = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
        
        [RXReadUtilites sharedInstance].chapters = [NSMutableArray arrayWithArray:jsonObject[@"chapters"]];
        [RXReadUtilites sharedInstance].chapterList = [NSMutableArray arrayWithArray:jsonObject[@"chapterList"]];
        //在这里做数据解析
        NSArray <RXChapterModel *> *readChapterList = [RXChapterModel mj_objectArrayWithKeyValuesArray:jsonObject[@"chapters"]];
        NSMutableDictionary *readChapterListModel = [NSMutableDictionary dictionary];
        for (RXChapterModel *model in readChapterList) {
            [readChapterListModel rx_setObject:model forKey:model.link];
        }
        
        NSArray <RXChapterModel *> *allChapterListModel = [RXChapterModel mj_objectArrayWithKeyValuesArray:jsonObject[@"chapterList"]];
        
        NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithObjects:@[readChapterListModel,allChapterListModel,jsonObject[@"currentPage"],jsonObject[@"currentChapter"]] forKeys:@[@"readChapterListModel",@"allChapterListModel",@"currentPage",@"currentChapter"]];
        
        return dict;
    }
    return nil;
}

+ (void)saveBookToShelfsBookWithBookArray:(NSMutableArray *)bookArray{
    NSString *path = [NSFileManager pathForBookShelfWithName:@"bookShelf.json"];
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:bookArray options:NSJSONWritingPrettyPrinted error:nil];
    
    NSString *fileString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
    
    [fileString writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
}

+ (NSMutableArray *)getBookshelfsBook{
    NSString *path = [NSFileManager pathForBookShelfWithName:@"bookShelf.json"];
     RXLog(@"%@",path);
    NSData *data = [NSData dataWithContentsOfFile:path];
    if(data){
        id jsonObject = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
        return jsonObject;
    }
    return nil;
}

- (void)resetInstance{
    [self.chapters removeAllObjects];
    [self.chapterList removeAllObjects];
}
@end
