//
//  RXChapterListModel.m
//  RXBookRead
//
//  Created by Evan on 2018/6/5.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXChapterListModel.h"
#import "RXChapterModel.h"


@implementation RXChapterListModel
+ (NSDictionary *)mj_objectClassInArray{
    return @{@"chapters" : [RXChapterModel class]};
}

+ (NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{ @"ID" : @"_id"};
}

-(void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:self.chapters forKey:@"chapters"];
    [aCoder encodeObject:self.ID forKey:@"ID"];
    [aCoder encodeObject:self.book forKey:@"book"];
}
-(id)initWithCoder:(NSCoder *)aDecoder{
    self = [super init];
    if (self) {
        self.chapters = [aDecoder decodeObjectForKey:@"chapters"];
        self.ID = [aDecoder decodeObjectForKey:@"ID"];
        self.book = [aDecoder decodeObjectForKey:@"book"];
    }
    return self;
}
@end
