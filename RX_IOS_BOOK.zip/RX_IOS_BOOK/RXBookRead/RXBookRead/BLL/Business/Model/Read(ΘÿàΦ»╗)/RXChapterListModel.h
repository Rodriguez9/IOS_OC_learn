//
//  RXChapterListModel.h
//  RXBookRead
//
//  Created by Evan on 2018/6/5.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXObject.h"

@class RXRecordModel,RXChapterModel;
@interface RXChapterListModel : RXObject

@property (nonatomic, copy) NSString *ID;
//书籍ID
@property (nonatomic, copy) NSString *book;
@property (nonatomic, strong) NSArray <RXChapterModel *> *chapters;
@end

