//
//  RXCategoryModel.h
//  RXBookRead
//
//  Created by Evan on 2018/6/1.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXObject.h"

@interface RXCategoryModel : RXObject
@property (nonatomic, strong) NSArray *male;
@end

@interface RXCategoryDetailModel :RXObject
@property (nonatomic, copy) NSString *name;
@property (nonatomic, strong) NSArray *bookCover;
@end
