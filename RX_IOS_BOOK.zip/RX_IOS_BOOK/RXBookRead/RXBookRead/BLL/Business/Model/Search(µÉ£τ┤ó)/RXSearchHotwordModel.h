//
//  RXSearchHotwordModel.h
//  RXBookRead
//
//  Created by Evan on 2018/6/2.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXObject.h"

@interface RXSearchHotwordModel : RXObject
@property (nonatomic, strong) NSMutableArray *hotWords;
@end
