//
//  RXBookDetailModel.h
//  RXBookRead
//
//  Created by Evan on 2018/5/31.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXObject.h"

@interface RXBookDetailModel : RXObject
@property (nonatomic, copy) NSString *ID;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *author;
@property (nonatomic, copy) NSString *longIntro;
@property (nonatomic, copy) NSString *cover;
@property (nonatomic, copy) NSString *majorCate;
@property (nonatomic, copy) NSString *lastChapter;
@property (nonatomic, copy) NSString *updated;
//是否完结（true 没有完结  false 完结了）
@property (nonatomic, assign) BOOL isSerial;
//是否有版权
@property (nonatomic, assign) BOOL hasCopyright;

//辅助属性
@property (nonatomic, copy) NSString *updateTime;

@property (nonatomic, assign) CGFloat cellHeight;
@end
