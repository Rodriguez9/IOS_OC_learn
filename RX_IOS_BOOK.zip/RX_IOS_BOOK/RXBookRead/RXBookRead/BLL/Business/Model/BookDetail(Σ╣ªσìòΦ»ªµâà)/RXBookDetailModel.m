//
//  RXBookDetailModel.m
//  RXBookRead
//
//  Created by Evan on 2018/5/31.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXBookDetailModel.h"
#import "NSDate+RXExtension.h"

@implementation RXBookDetailModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{ @"ID" : @"_id"};
}

- (void)setUpdated:(NSString *)updated{
    _updated = updated;
    NSString *newStr = [[updated substringToIndex:19] stringByReplacingOccurrencesOfString:@"T" withString:@" "];
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSDate *date = [formatter dateFromString:newStr];
    self.updateTime = [date bookDetailTimeInfo];
}
@end
