//
//  RXConst_system.h
//  RXBookRead
//
//  Created by Evan on 2018/5/29.
//  Copyright © 2018年 Evan. All rights reserved.
//

#ifndef RXConst_system_h
#define RXConst_system_h


#ifdef DEBUG
#define RXLog(...) NSLog(__VA_ARGS__)
#else
#define RXLog(...)
#endif

/**************************************字体******************************************/
/** 普通字体 */
#define     RXFont(size)                    [UIFont systemFontOfSize:iPhone_7Plus ? size * 1.15 : size]
#define     RXCustomFont(fontName,fontSize) [UIFont fontWithName:fontName size:iPhone_7Plus ? fontSize * 1.15 : fontSize]

/**************************************颜色******************************************/
#define RXColor(r, g, b, a)             [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:a]
#define RXHexColor(String)              [RXSystemManager colorWithHexString:String]
#define RXNotificationCenter            [NSNotificationCenter defaultCenter]
#define RXUserDefault                   [NSUserDefaults standardUserDefaults]
#define RXURL(urlString)                [NSURL URLWithString:urlString]
#define RXFILEURL(urlPath)              [NSURL fileURLWithPath:urlPath]
#define RXWeakSelf(type)                __weak typeof(type) weak##type = type;
#define RXStrongSelf(type)              __strong typeof(type) strong##type = type;
#define RXDocumentDirectory             [(NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)) lastObject]

#define APP_VERSION  [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"]

#define Cache_Path [NSString stringWithFormat:@"%@/User/JSON", RXDocumentDirectory]
#endif /* RXConst_system_h */
