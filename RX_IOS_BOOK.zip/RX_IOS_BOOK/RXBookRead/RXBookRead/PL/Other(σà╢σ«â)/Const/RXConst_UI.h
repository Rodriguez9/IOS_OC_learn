//
//  RXConst_UI.h
//  RXBookRead
//
//  Created by Evan on 2018/5/29.
//  Copyright © 2018年 Evan. All rights reserved.
//

#ifndef RXConst_UI_h
#define RXConst_UI_h

#define iOS10_OR_LATER ( ([[[UIDevice currentDevice] systemVersion] floatValue]>=10.0) ? YES : NO )

//尺寸
#define     SCREEN_RECT                 [RXSystemManager screenRect]
#define     SIZE_SCREEN                 SCREEN_RECT.size
#define     WIDTH_SCREEN                SIZE_SCREEN.width
#define     HEIGHT_SCREEN               SIZE_SCREEN.height
#define     HEIGHT_STATUSBAR            20.0f
#define     HEIGHT_TABBAR               49.0f
#define     HEIGHT_NAVBAR               44.0f
#define     NAVBAR_ITEM_FIXED_SPACE     5.0f
#define     HEIGHT_NAV                  (HEIGHT_NAVBAR + HEIGHT_STATUSBAR)

/** 各机型与i6的宽高比例系数  */
#define     HeightScale                     HEIGHT_SCREEN / 667
#define     WidthScale                      WIDTH_SCREEN / 375

/**************************************机型*****************************************/
#define     iPhone_5                        (HEIGHT_SCREEN == 568)
#define     iPhone_4                        (HEIGHT_SCREEN == 480)
#define     iPhone_6                        (HEIGHT_SCREEN == 667)
#define     iPhone_7Plus                    (HEIGHT_SCREEN == 736)
#define     iPhone_X                        (HEIGHT_SCREEN == 812)

/************ iphone_x尺寸适配 ****************/
/*** iPhoneX底部虚拟区适配 */
//iphoneX底部虚拟区高度
#define     HEIGHT_VIRTUAL_IX               34.0f
#define     HEIGHT_VIRTUAL_FIT              (iPhone_X ? HEIGHT_VIRTUAL_IX : 0)
/*** iPhoneX底部Tabbar   */
//iphoneX底部Tabbar高度
#define     HEIGHT_TABBAR_IX                (HEIGHT_VIRTUAL_IX + HEIGHT_TABBAR)

/** 导航栏高度(内部控件已适配) */
//iphoneX下导航条需要增加的高度
#define     HEIGHT_NAVADD_IX                 24.0f
//iphoneX下导航条高度
#define     HEIGHT_NAV_IX                   HEIGHT_NAV + HEIGHT_NAVADD_IX
#define     HEIGHT_NAVADD_FIT               (iPhone_X ? HEIGHT_NAVADD_IX : 0)

//底部Tabbar高度： X是(34+49)  非X是(49)
#define     HEIGHT_TABBAR_FIT               (iPhone_X ? HEIGHT_TABBAR_IX : HEIGHT_TABBAR)
//导航高度: X是(64+24) 非X是(64)
#define     HEIGHT_NAV_FIT                  (iPhone_X ? HEIGHT_NAV_IX : HEIGHT_NAV)


#endif /* RXConst_UI_h */
