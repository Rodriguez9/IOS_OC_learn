//
//  RXConst_key.h
//  RXBookRead
//
//  Created by Evan on 2018/6/4.
//  Copyright © 2018年 Evan. All rights reserved.
//

#ifndef RXConst_key_h
#define RXConst_key_h

#define RXNoteNotification @"RXNoteNotification"
#define RXThemeNotification @"RXThemeNotification"
#define RXEditingNotification @"RXEditingNotification"
#define RXEndEditNotification @"RXEndEditNotification"
#define RXBookShelfNotification @"RXBookShelfNotification"

#define MinFontSize 11.0f
#define MaxFontSize 20.0f

#define Contact_US @"QQ群：781222598"


#define AppId @"1105344611"
#define PlacementId @"9040714184494018"

#define GAME_ID @"2"

#define AStr @"/ : Y A P I L A"

#define WStr @"/ : N I X I E W"

#define EnterStr  @"N C . C S W M F C . L L E W / / : S P T T H"

//游戏id
#define APP_ID                       (@"2")

//版本号
#define IOS_VERSION                      (@"ios2159.0")

#define AGENT_ID                       (@"")

#define PLACED_ID                      (@"")

#endif /* RXConst_key_h */
