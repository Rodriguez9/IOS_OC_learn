//
//  RXCurrentReadController.h
//  RXBookRead
//
//  Created by Evan on 2018/6/5.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXBaseController.h"
#import "RXReadView.h"

@interface RXCurrentReadController : RXBaseController
@property (nonatomic,strong) NSString *content; //显示的内容
@property (nonatomic,strong) RXReadView *readView;
@end
