//
//  RXChapterVC.m
//  RXBookRead
//
//  Created by Evan on 2018/6/5.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXChapterVC.h"
#import "RXCatalogController.h"
#import "RXChapterModel.h"

#define cellIndifier @"RXChapterCell"
@interface RXChapterVC ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) RXTableView *tableView;
@end

@implementation RXChapterVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.tableView];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:cellIndifier];
//    if (@available(iOS 11.0, *)) {
//        self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
//    } else {
//        self.automaticallyAdjustsScrollViewInsets = NO;
//    }
}

- (void)setChapterModel:(RXChapterModel *)chapterModel{
    _chapterModel = chapterModel;
    [self.tableView reloadData];
}

#pragma mark - UITableView Delagete DataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.model.chapters.count;;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIndifier];
    RXChapterModel *model = self.model.chapters[indexPath.row];
    if (indexPath.row == self.chapterModel.chapter - 1) {
        [tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionMiddle];
    }
    cell.textLabel.text = model.title;
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return  44.0f;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([self.delegate respondsToSelector:@selector(catalog:didSelectChapter:page:)]) {
        [self.delegate catalog:nil didSelectChapter:indexPath.row page:0];
    }
}

- (RXTableView *)tableView {
    if (!_tableView) {
        RXTableView *tableView = [[RXTableView alloc] initWithFrame:CGRectMake(0, 0, WIDTH_SCREEN, HEIGHT_SCREEN)];
        [tableView setBackgroundColor:[UIColor whiteColor]];
        tableView.delegate = self;
        tableView.dataSource = self;
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
        _tableView = tableView;
    }
    return _tableView;
}
@end
