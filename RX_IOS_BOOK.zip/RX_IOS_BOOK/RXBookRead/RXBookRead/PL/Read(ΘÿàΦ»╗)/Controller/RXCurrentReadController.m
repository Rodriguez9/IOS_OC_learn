//
//  RXCurrentReadController.m
//  RXBookRead
//
//  Created by Evan on 2018/6/5.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXCurrentReadController.h"
#import "RXReadConfig.h"

@interface RXCurrentReadController ()

@end

@implementation RXCurrentReadController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self prefersStatusBarHidden];
    [self.view setBackgroundColor:[RXReadConfig shareInstance].theme];
    [self.view addSubview:self.readView];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeTheme:) name:RXThemeNotification object:nil];
}


-(void)changeTheme:(NSNotification *)no
{
    [RXReadConfig shareInstance].theme = no.object;
    [self.view setBackgroundColor:[RXReadConfig shareInstance].theme];
}

-(RXReadView *)readView
{
    if (!_readView) {
        _readView = [[RXReadView alloc] initWithFrame:CGRectMake(20,40 + HEIGHT_NAVADD_FIT, self.view.frame.size.width-20-20, self.view.frame.size.height-40-50 - HEIGHT_NAVADD_FIT - HEIGHT_NAVADD_FIT)];
        RXReadConfig *config = [RXReadConfig shareInstance];
        _readView.frameRef = [RXReadConfig parserContent:_content config:config bouds:CGRectMake(0,0, _readView.frame.size.width, _readView.frame.size.height)];
    }
    return _readView;
}

- (void)dealloc{
    [RXNotificationCenter removeObserver:self];
}
@end
