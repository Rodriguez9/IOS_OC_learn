//
//  RXReadViewController.m
//  RXBookRead
//
//  Created by Evan on 2018/6/4.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXReadViewController.h"
#import "RXCatalogController.h"
#import "RXCurrentReadController.h"
#import "RXMenuView.h"
#import "RXChapterModel.h"
#import "RXReadUtilites.h"
#import "GDTMobBannerView.h"
#import "GDTMobInterstitial.h"
#import "DZMCoverController.h"

@interface RXReadViewController ()<RXMenuViewDelegate,UIGestureRecognizerDelegate,RXCatalogControllerDelegate,GDTMobBannerViewDelegate,GDTMobInterstitialDelegate,DZMCoverControllerDelegate>
//自定义的翻页控制器(只支持混动，不支持翻页)
@property (nonatomic,strong) DZMCoverController *coverVC;
//菜单栏
@property (nonatomic, strong) RXMenuView *menuView;
//侧边栏控制器
@property (nonatomic,strong) RXCatalogController *catalogVC;
//侧边栏背景
@property (nonatomic,strong) UIView * catalogView;
//当前阅读视图
@property (nonatomic, strong) RXCurrentReadController *readView;
//将要变化的章节
@property (nonatomic, assign) NSUInteger chapterChange;
//将要变化的页数
@property (nonatomic, assign) NSUInteger pageChange;

@property (nonatomic, strong) RXChapterModel *chapterModel;

@property (nonatomic, strong) NSMutableDictionary *preCaheModelDict;

@property (nonatomic, strong) GDTMobBannerView *bannerView;

@property (nonatomic, strong) GDTMobInterstitial *interstitial;

@property (nonatomic, assign) NSInteger hadReadPage;

@end

@implementation RXReadViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    NSMutableDictionary *dict = [RXReadUtilites getDownLoadedChapter:self.bookId];
    if (dict) { //已经阅读过
        //重新装数组模型
        self.model.chapters = dict[@"allChapterListModel"];
        self.pageChange = [dict[@"currentPage"] integerValue];
        self.preCaheModelDict = dict[@"readChapterListModel"];
        self.chapterChange = [dict[@"currentChapter"] integerValue];
        [self setupUI];
    }else{ //没有阅读过,需下载
        self.chapterChange = 1;
        self.pageChange = 0;
        RXWeakSelf(self);
        [self getChapterListComplete:^{
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakself setupUI];
            });
            
        }];
    }
}

//退出时对下载了小说进行缓存
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    NSArray *readChapterArray = [RXReadUtilites sharedInstance].chapters;
    if (readChapterArray.count) {
        NSArray *chapterList = [RXReadUtilites sharedInstance].chapterList;
        NSMutableDictionary *tempDic = [NSMutableDictionary dictionaryWithObjects:@[@(self.chapterChange),@(self.pageChange),readChapterArray,chapterList] forKeys:@[@"currentChapter",@"currentPage",@"chapters",@"chapterList"]];
        [RXReadUtilites saveDownLoadedChapter:self.bookId preChapterDict:tempDic];
        //更新书架阅读记录
        [RXNotificationCenter postNotificationName:RXBookShelfNotification object:nil];
    }
//    //把广告banner都置为空
//    self.bannerView.currentViewController = nil;
//    self.bannerView.delegate = nil;
//    [self.bannerView removeFromSuperview];
//    self.bannerView = nil;
}

- (void)setupUI{
    [self addChildViewController:self.coverVC];
    [self.coverVC setController:self.readView];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showToolMenu)];
    tap.delegate = self;
    [self.view addGestureRecognizer:tap];
    [self.view addSubview:self.menuView];
    
    [self addChildViewController:self.catalogVC];
    [self.view addSubview:self.catalogView];
    [self.catalogView addSubview:self.catalogVC.view];
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        [self loadBanerView];
//        [self loadAd];
//    });
   
}

- (void)loadBanerView{
    self.bannerView.currentViewController = nil;
    self.bannerView.delegate = nil;
    [self.bannerView removeFromSuperview];
    self.bannerView = nil;
    [self.view addSubview:self.bannerView];
    self.bannerView.frame = CGRectMake(0, HEIGHT_SCREEN - 50 - HEIGHT_NAVADD_FIT, WIDTH_SCREEN, 50 + HEIGHT_NAVADD_FIT);
    [self.bannerView loadAdAndShow];
}

- (void)loadAd{
    if(self.interstitial) {
        self.interstitial.delegate = nil;
    }
    self.interstitial = [[GDTMobInterstitial alloc] initWithAppId:AppId placementId:@"2030814134092814"];
    self.interstitial.delegate = self;
    
    [self.interstitial loadAd];
}
//获取章节列表，如果是从第一章开始看的加载0-5章
- (void)getChapterListComplete:(void(^)(void))complete{
    RXWeakSelf(self);
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [RXAPIManager getChapterListWithBookId:self.bookId success:^(RXChapterListModel *chapterListModel) {
        dispatch_async(dispatch_get_main_queue(), ^{
            weakself.model = chapterListModel;
            for (NSInteger i =0; i < 5; i++) {
                NSString *link = ((RXChapterModel *)[self.model.chapters rx_objectAtIndex:i]).link;
                [RXAPIManager getChapterDetailWithLink:link success:^(RXChapterModel *chapterModel) {
                    [MBProgressHUD hideHUDForView:weakself.view animated:YES];
                    [weakself.preCaheModelDict rx_setObject:chapterModel forKey:chapterModel.link];
                    if (i == 4) {
                        if (complete) {
                            complete();
                        }
                    }
                } failure:^(NSError *error) {
                    [MBProgressHUD hideHUDForView:weakself.view animated:YES];
                }];
            }
        });
    } failure:^(NSError *error) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [MBProgressHUD hideHUDForView:weakself.view animated:YES];
            [[iToast makeText:@"该书暂不支持阅读！！！"] show];
            [weakself dismissViewControllerAnimated:YES completion:nil];
        });
        
    }];
}

//获取章节的详细信息(大于0章看的加载选的这章和前一章以及后三章)
- (void)getChaterDetaiWithChapter:(NSUInteger)chapter complete:(void(^)(void))complete{
    RXWeakSelf(self);
    NSMutableArray *tempArray = [NSMutableArray array];
    [tempArray addObjectsFromArray:self.preCaheModelDict.allValues];
    NSInteger tempChapter = chapter - 1;
    for (NSInteger i = tempChapter; i < tempChapter + 5; i++) {
        NSString *link = ((RXChapterModel *)[self.model.chapters rx_objectAtIndex:i - 1]).link;
        //未下载的才需要下载
        BOOL download = [RXUtilites isThisChapterNeedDownLoad:tempArray link:link];
        if (download) {
            [RXAPIManager getChapterDetailWithLink:link success:^(RXChapterModel *chapterModel) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [MBProgressHUD hideHUDForView:weakself.view animated:YES];
                    [tempArray addObject:chapterModel];
                    [weakself.preCaheModelDict rx_setObject:chapterModel forKey:chapterModel.link];
                    if (i == tempChapter + 4) {
                        if (complete) {
                            complete();
                        }
                    }
                });
                
            } failure:^(NSError *error) {
                [MBProgressHUD hideHUDForView:weakself.view animated:YES];
            }];
        }else{
            if (i == tempChapter + 4) {
                if (complete) {
                    complete();
                }
            }
        }
    }
}

//每次看完一章预加载一章
- (void)loadNewChapterWithIsloadPreChapter:(BOOL)isloadPreChapter{
    RXWeakSelf(self);
    NSString *link = nil;
    if (isloadPreChapter) { //往前翻时加载前一章
        link = ((RXChapterModel *)[self.model.chapters rx_objectAtIndex:self.chapterChange]).link;
    }else{ //加载正在阅读的后面第5章
        link = ((RXChapterModel *)[self.model.chapters rx_objectAtIndex:self.chapterChange + 2]).link;
    }
    
    //未下载的才需要下载
    BOOL download = [RXUtilites isThisChapterNeedDownLoad:[NSMutableArray arrayWithArray:self.preCaheModelDict.allValues] link:link];
    if (download) {
        [RXAPIManager getChapterDetailWithLink:link success:^(RXChapterModel *chapterModel) {
            [weakself.preCaheModelDict rx_setObject:chapterModel forKey:chapterModel.link];
        } failure:^(NSError *error) {
            
        }];
    }
   
    
}
-(void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    _coverVC.view.frame = self.view.frame;
    _catalogVC.view.frame = CGRectMake(0, 0, self.view.mp_width - 100, self.view.mp_height);
    [_catalogVC reload];
}

-(void)showToolMenu
{
    [self.menuView showAnimation:YES];
    [self.view bringSubviewToFront:self.menuView];
}
-(void)hiddenCatalog
{
    [self catalogShowState:NO];
}

#pragma mark - Privite Method
-(void)catalogShowState:(BOOL)show
{
    show?({
        _catalogView.hidden = !show;
        [UIView animateWithDuration:0.3 animations:^{
            self.catalogView.frame = CGRectMake(0, 0,2*self.view.mp_width, self.view.mp_height);
            
        } completion:^(BOOL finished) {
            [self.catalogView insertSubview:[[UIImageView alloc] initWithImage:[UIImage blurredSnapshotWithView:self.view]] atIndex:0];
        }];
    }):({
        if ([_catalogView.subviews.firstObject isKindOfClass:[UIImageView class]]) {
            [_catalogView.subviews.firstObject removeFromSuperview];
        }
        [UIView animateWithDuration:0.3 animations:^{
            self.catalogView.frame = CGRectMake(-self.view.mp_width, 0, 2*self.view.mp_width, self.view.mp_height);
        } completion:^(BOOL finished) {
            self.catalogView.hidden = !show;
            
        }];
    });
}

//解决TabView与Tap手势冲突
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if ([NSStringFromClass([touch.view class]) isEqualToString:@"UITableViewCellContentView"]) {
        return NO;
    }
    return  YES;
}

#pragma mark - CatalogViewController Delegate
-(void)catalog:(RXCatalogController *)catalog didSelectChapter:(NSUInteger)chapter page:(NSUInteger)page
{
    self.readView = nil;
    self.chapterChange = chapter + 1;
    self.pageChange = page;
    RXWeakSelf(self);
    [self getChaterDetaiWithChapter:self.chapterChange complete:^{
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakself.coverVC setController:weakself.readView];
            [weakself hiddenCatalog];
//            //每次新的一章显示广告
//            [self loadBanerView];
        });
    }];
}
#pragma mark menuViewDelegate
-(void)menuViewFontSize:(RXBottomMenuView *)bottomMenu
{
    [self.chapterModel updateFont];
    self.readView = nil;
    [self.coverVC setController:self.readView];
}

- (void)menuViewJumpChapter:(RXBottomMenuView *)bottomMenu isNextChapter:(BOOL)isNextChapter{
    if ((self.chapterChange == 1 && !isNextChapter) || (self.chapterChange == self.model.chapters.count + 1 && isNextChapter)) {
        return;
    }
    self.readView = nil;
    self.pageChange = 0;
    if (isNextChapter) {
        self.chapterChange++;
        [self loadNewChapterWithIsloadPreChapter:NO];
    }else{
         self.chapterChange--;
         [self loadNewChapterWithIsloadPreChapter:YES];
    }
    [self.coverVC setController:self.readView];
    
//    //每次新的一章显示广告
//    [self loadBanerView];
}

- (void)menuViewJumpChapter:(RXBottomMenuView *)bottomMenu sliderValue:(float)sliderValue{
     NSUInteger page =ceil((self.chapterModel.pageCount-1) * sliderValue/100.00);
    self.readView = nil;
    self.pageChange = page;
    [self.coverVC setController:self.readView];
}

-(void)menuViewInvokeCatalog:(RXBottomMenuView *)bottomMenu{
    [_menuView hiddenAnimation:NO];
    [self catalogShowState:YES];
    
}

#pragma mark - DZMCoverControllerDelegate

// 切换结果
- (void)coverController:(DZMCoverController *)coverController currentController:(UIViewController *)currentController finish:(BOOL)isFinish{
   
}

// 上一个控制器
- (UIViewController *)coverController:(DZMCoverController *)coverController getAboveControllerWithCurrentController:(UIViewController *)currentController{
    self.readView = nil;
    if (_chapterChange == 1 &&_pageChange == 0) {
        return nil;
    }
    if (_pageChange ==0 ) {
        _chapterChange--;
        NSString *link = ((RXChapterModel *)[self.model.chapters rx_objectAtIndex:self.chapterChange - 1]).link;
        _pageChange = ((RXChapterModel *)[self.preCaheModelDict objectForKey:link]).pageCount - 1;
        [self loadNewChapterWithIsloadPreChapter:YES];
//        //每次新的一章显示广告
//        [self loadBanerView];
    }
    else{
        _pageChange--;
    }
    
    return self.readView;
}

// 下一个控制器
- (UIViewController *)coverController:(DZMCoverController *)coverController getBelowControllerWithCurrentController:(UIViewController *)currentController{
    //记录用户看了几页(每看15页弹出插件广告)
    self.hadReadPage++;
    RXWeakSelf(self);
    if (self.hadReadPage % 15 == 0) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakself.interstitial presentFromRootViewController:weakself];
        });
        
    }
    self.readView = nil;
    if (_pageChange == self.chapterModel.pageCount-1 && _chapterChange == _model.chapters.count-1) {
        return nil;
    }
    if (_pageChange == self.chapterModel.pageCount-1) {
        _chapterChange++;
        _pageChange = 0;
        [self loadNewChapterWithIsloadPreChapter:NO];
//        //每次新的一章显示广告
//        [self loadBanerView];
    }
    else{
        _pageChange++;
    }
    return self.readView;
}
#pragma mark - GDTMobBannerViewDelegate
// 请求广告条数据成功后调用
//
// 详解:当接收服务器返回的广告数据成功后调用该函数
- (void)bannerViewDidReceived
{
    NSLog(@"banner Received");
}

// 请求广告条数据失败后调用
//
// 详解:当接收服务器返回的广告数据失败后调用该函数
- (void)bannerViewFailToReceived:(NSError *)error
{
    NSLog(@"banner failed to Received : %@",error);
}

// 广告栏被点击后调用
//
// 详解:当接收到广告栏被点击事件后调用该函数
- (void)bannerViewClicked
{
    NSLog(@"banner clicked");
}

// 应用进入后台时调用
//
// 详解:当点击下载或者地图类型广告时，会调用系统程序打开，
// 应用将被自动切换到后台
- (void)bannerViewWillLeaveApplication
{
    NSLog(@"banner leave application");
}


-(void)bannerViewDidDismissFullScreenModal
{
    NSLog(@"%s",__FUNCTION__);
}

-(void)bannerViewWillDismissFullScreenModal
{
    NSLog(@"%s",__FUNCTION__);
}

-(void)bannerViewWillPresentFullScreenModal
{
    NSLog(@"%s",__FUNCTION__);
}

-(void)bannerViewDidPresentFullScreenModal
{
    NSLog(@"%s",__FUNCTION__);
}

#pragma mark - GDTMobInterstitialDelegate
// 广告预加载成功回调
//
// 详解:当接收服务器返回的广告数据成功后调用该函数
- (void)interstitialSuccessToLoadAd:(GDTMobInterstitial *)interstitial
{
    
}

// 广告预加载失败回调
//
// 详解:当接收服务器返回的广告数据失败后调用该函数
- (void)interstitialFailToLoadAd:(GDTMobInterstitial *)interstitial error:(NSError *)error
{
   
}

// 插屏广告将要展示回调
//
// 详解: 插屏广告即将展示回调该函数
- (void)interstitialWillPresentScreen:(GDTMobInterstitial *)interstitial
{
    
}

// 插屏广告视图展示成功回调
//
// 详解: 插屏广告展示成功回调该函数
- (void)interstitialDidPresentScreen:(GDTMobInterstitial *)interstitial
{
    
}

// 插屏广告展示结束回调
//
// 详解: 插屏广告展示结束回调该函数
- (void)interstitialDidDismissScreen:(GDTMobInterstitial *)interstitial
{
    [self loadAd];
}

// 应用进入后台时回调
//
// 详解: 当点击下载应用时会调用系统程序打开，应用切换到后台
- (void)interstitialApplicationWillEnterBackground:(GDTMobInterstitial *)interstitial
{
    
}

#pragma mark - init
-(RXMenuView *)menuView
{
    if (!_menuView) {
        _menuView = [[RXMenuView alloc] initWithFrame:self.view.frame];
        _menuView.hidden = YES;
        _menuView.delegate = self;
        _menuView.chapterModel = self.chapterModel;
    }
    return _menuView;
}

- (DZMCoverController *)coverVC{
    if (!_coverVC) {
        _coverVC = [[DZMCoverController alloc] init];
        _coverVC.delegate = self;
        [self.view addSubview:_coverVC.view];
    }
    return _coverVC;
}
-(RXCatalogController *)catalogVC
{
    if (!_catalogVC) {
        _catalogVC = [[RXCatalogController alloc] init];
        _catalogVC.catalogDelegate = self;
        _catalogVC.chapterModel = self.chapterModel;
        _catalogVC.model = self.model;
    }
    return _catalogVC;
}
-(UIView *)catalogView
{
    if (!_catalogView) {
        _catalogView = [[UIView alloc] initWithFrame:CGRectMake(-self.view.mp_width, 0, 2 * self.view.mp_width, self.view.mp_height)];
        _catalogView.backgroundColor = [UIColor clearColor];
        _catalogView.hidden = YES;
        [_catalogView addGestureRecognizer:({
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hiddenCatalog)];
            tap.delegate = self;
            tap;
        })];
    }
    return _catalogView;
}

- (RXCurrentReadController *)readView{
    if (!_readView) {
        _readView = [[RXCurrentReadController alloc] init];
        NSString *link = ((RXChapterModel *)[self.model.chapters rx_objectAtIndex:self.chapterChange - 1]).link;
        self.chapterModel = [self.preCaheModelDict objectForKey:link];
        _readView.content = [self.chapterModel stringOfPage:self.pageChange];
        self.chapterModel.page = self.pageChange;
        self.chapterModel.chapter = self.chapterChange;
        self.catalogVC.chapterModel = self.chapterModel;
        self.menuView.chapterModel = self.chapterModel;
    }
    return _readView;
}

- (GDTMobBannerView *)bannerView
{
    if (!_bannerView) {
        _bannerView = [[GDTMobBannerView alloc] initWithAppId:AppId placementId:@"4090812164690039"];
        _bannerView.currentViewController = self;
        _bannerView.interval = 30;
        _bannerView.isAnimationOn = YES;
        _bannerView.showCloseBtn = YES;
        _bannerView.delegate = self;
    }
    return _bannerView;
}
- (NSMutableDictionary *)preCaheModelDict{
    if (!_preCaheModelDict) {
        _preCaheModelDict = [NSMutableDictionary dictionary];
    }
    return _preCaheModelDict;
}

- (RXChapterListModel *)model{
    if (!_model) {
        _model = [[RXChapterListModel alloc] init];
    }
    return _model;
}
@end
