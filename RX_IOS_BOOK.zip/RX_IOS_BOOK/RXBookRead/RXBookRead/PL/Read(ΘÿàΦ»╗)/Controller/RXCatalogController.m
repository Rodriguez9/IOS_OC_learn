//
//  RXCatalogController.m
//  RXBookRead
//
//  Created by Evan on 2018/6/5.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXCatalogController.h"
#import "RXChapterVC.h"
#import "RXMarkVC.h"


@interface RXCatalogController ()<LSYViewPagerVCDelegate,LSYViewPagerVCDataSource,RXCatalogControllerDelegate>

@property (nonatomic, strong) NSArray *titleArray;

@property (nonatomic, strong) NSArray *VCArray;

@property (nonatomic, strong) RXChapterVC *chapterVC;
@end

@implementation RXCatalogController

- (RXChapterVC *)chapterVC{
    if (!_chapterVC) {
        _chapterVC = [[RXChapterVC alloc]init];
        _chapterVC.delegate = self;
    }
    return _chapterVC;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    _titleArray = @[@"目录"];
    _VCArray = @[self.chapterVC];
    self.chapterVC.model = self.model;
    self.forbidGesture = YES;
    self.delegate = self;
    self.dataSource = self;
}

- (void)setChapterModel:(RXChapterModel *)chapterModel{
    _chapterModel = chapterModel;
    self.chapterVC.chapterModel = chapterModel;
}

-(NSInteger)numberOfViewControllersInViewPager:(LSYViewPagerVC *)viewPager
{
    return _titleArray.count;
}
-(UIViewController *)viewPager:(LSYViewPagerVC *)viewPager indexOfViewControllers:(NSInteger)index
{
    return _VCArray[index];
}
-(NSString *)viewPager:(LSYViewPagerVC *)viewPager titleWithIndexOfViewControllers:(NSInteger)index
{
    return _titleArray[index];
}
-(CGFloat)heightForTitleOfViewPager:(LSYViewPagerVC *)viewPager
{
    return 40.0f + HEIGHT_NAVADD_FIT;
}
-(CGFloat)heightForHeaderOfViewPager:(LSYViewPagerVC *)viewPager{
    return 40.0f + HEIGHT_NAVADD_FIT;
}
-(void)catalog:(RXCatalogController *)catalog didSelectChapter:(NSUInteger)chapter page:(NSUInteger)page
{
    if ([self.catalogDelegate respondsToSelector:@selector(catalog:didSelectChapter:page:)]) {
        [self.catalogDelegate catalog:self didSelectChapter:chapter page:page];
    }
}
@end
