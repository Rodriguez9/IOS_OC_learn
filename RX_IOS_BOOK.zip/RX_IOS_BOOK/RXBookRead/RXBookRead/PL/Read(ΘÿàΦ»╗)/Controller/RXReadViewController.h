//
//  RXReadViewController.h
//  RXBookRead
//
//  Created by Evan on 2018/6/4.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXBaseController.h"
#import "RXChapterListModel.h"

@interface RXReadViewController : RXBaseController
@property (nonatomic, strong) RXChapterListModel *model;
@property (nonatomic, copy) NSString *bookId;
@end
