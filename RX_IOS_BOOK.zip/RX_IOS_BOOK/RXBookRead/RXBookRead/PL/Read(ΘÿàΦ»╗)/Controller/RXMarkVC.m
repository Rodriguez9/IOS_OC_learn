//
//  RXMarkVC.m
//  RXBookRead
//
//  Created by Evan on 2018/6/5.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXMarkVC.h"

@interface RXMarkVC ()

@end

@implementation RXMarkVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
}

@end
