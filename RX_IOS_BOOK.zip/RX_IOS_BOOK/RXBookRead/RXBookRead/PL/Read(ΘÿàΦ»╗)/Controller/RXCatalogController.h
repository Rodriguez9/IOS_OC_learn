//
//  RXCatalogController.h
//  RXBookRead
//
//  Created by Evan on 2018/6/5.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "LSYViewPagerVC.h"
#import "RXChapterListModel.h"
#import "RXChapterModel.h"

@class RXCatalogController;
@protocol RXCatalogControllerDelegate <NSObject>
@optional
-(void)catalog:(RXCatalogController *)catalog didSelectChapter:(NSUInteger)chapter page:(NSUInteger)page;
@end

@interface RXCatalogController : LSYViewPagerVC
@property (nonatomic, weak) id<RXCatalogControllerDelegate>catalogDelegate;
@property (nonatomic, strong) RXChapterListModel *model;
@property (nonatomic, strong) RXChapterModel *chapterModel;
@end
