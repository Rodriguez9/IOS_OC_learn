//
//  RXReadConfig.h
//  RXBookRead
//
//  Created by Evan on 2018/6/4.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXObject.h"
#import <CoreText/CoreText.h>

@interface RXReadConfig : RXObject<NSCoding>
+(instancetype)shareInstance;
@property (nonatomic) CGFloat fontSize;
@property (nonatomic) CGFloat lineSpace;
@property (nonatomic,strong) UIColor *fontColor;
@property (nonatomic,strong) UIColor *theme;
+(NSDictionary *)parserAttribute:(RXReadConfig *)config;
+(CTFrameRef)parserContent:(NSString *)content config:(RXReadConfig *)parser bouds:(CGRect)bounds;
@end
