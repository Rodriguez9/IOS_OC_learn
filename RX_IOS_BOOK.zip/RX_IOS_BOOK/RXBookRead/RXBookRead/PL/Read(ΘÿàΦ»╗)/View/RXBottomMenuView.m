//
//  RXBottomMenuView.m
//  RXBookRead
//
//  Created by Evan on 2018/6/4.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXBottomMenuView.h"
#import "RXThemView.h"
#import "RXReadProgressView.h"
#import "RXReadConfig.h"
#import "RXMenuView.h"

@interface RXBottomMenuView()
@property (nonatomic, strong) RXThemView *themeView;
@property (nonatomic, strong) RXReadProgressView *progressView;
@property (nonatomic,strong) UIButton *catalog;
@property (nonatomic,strong) UISlider *slider;
@property (nonatomic,strong) UIButton *lastChapter;
@property (nonatomic,strong) UIButton *nextChapter;
@property (nonatomic,strong) UIButton *increaseFont;
@property (nonatomic,strong) UIButton *decreaseFont;
@property (nonatomic,strong) UILabel *fontLabel;
@end

@implementation RXBottomMenuView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setup];
    }
    return self;
}
-(void)setup{
    [self setBackgroundColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:0.8]];
    [self addSubview:self.slider];
    [self addSubview:self.catalog];
    [self addSubview:self.progressView];
    [self addSubview:self.lastChapter];
    [self addSubview:self.nextChapter];
    [self addSubview:self.increaseFont];
    [self addSubview:self.decreaseFont];
    [self addSubview:self.fontLabel];
    [self addSubview:self.themeView];

    [[RXReadConfig shareInstance] addObserver:self forKeyPath:@"fontSize" options:NSKeyValueObservingOptionNew context:NULL];
}

- (void)setChapterModel:(RXChapterModel *)chapterModel{
    _chapterModel = chapterModel;
     self.slider.value = chapterModel.page/((float)(chapterModel.pageCount-1))*100;
     [self.progressView progress:[NSString stringWithFormat:@"%.1f%%",_slider.value]];
    
}
-(UIButton *)catalog
{
    if (!_catalog) {
        _catalog = [RXUtilites commonButtonSEL:@selector(showCatalog) target:self];
        [_catalog setImage:[UIImage imageNamed:@"reader_cover"] forState:UIControlStateNormal];
    }
    return _catalog;
}
-(RXReadProgressView *)progressView
{
    if (!_progressView) {
        _progressView = [[RXReadProgressView alloc] init];
        _progressView.hidden = YES;
        
    }
    return _progressView;
}
-(UISlider *)slider
{
    if (!_slider) {
        _slider = [[UISlider alloc] init];
        _slider.minimumValue = 0;
        _slider.maximumValue = 100;
        _slider.minimumTrackTintColor = RXColor(227,0,0,1.0);
        _slider.maximumTrackTintColor = [UIColor whiteColor];
        [_slider setThumbImage:[self thumbImage] forState:UIControlStateNormal];
        [_slider setThumbImage:[self thumbImage] forState:UIControlStateHighlighted];
        [_slider addTarget:self action:@selector(changeMsg:) forControlEvents:UIControlEventValueChanged];
        [_slider addObserver:self forKeyPath:@"highlighted" options:NSKeyValueObservingOptionNew|NSKeyValueObservingOptionOld context:NULL];
        
    }
    return _slider;
}
-(UIButton *)nextChapter
{
    if (!_nextChapter) {
        _nextChapter = [RXUtilites commonButtonSEL:@selector(jumpChapter:) target:self];
        [_nextChapter setTitle:@"下一章" forState:UIControlStateNormal];
    }
    return _nextChapter;
}
-(UIButton *)lastChapter
{
    if (!_lastChapter) {
        _lastChapter = [RXUtilites commonButtonSEL:@selector(jumpChapter:) target:self];
        [_lastChapter setTitle:@"上一章" forState:UIControlStateNormal];
    }
    return _lastChapter;
}
-(UIButton *)increaseFont
{
    if (!_increaseFont) {
        _increaseFont = [RXUtilites commonButtonSEL:@selector(changeFont:) target:self];
        [_increaseFont setTitle:@"A+" forState:UIControlStateNormal];
        [_increaseFont.titleLabel setFont:[UIFont systemFontOfSize:17]];
        _increaseFont.layer.borderWidth = 1;
        _increaseFont.layer.borderColor = [UIColor whiteColor].CGColor;
    }
    return _increaseFont;
}
-(UIButton *)decreaseFont
{
    if (!_decreaseFont) {
        _decreaseFont = [RXUtilites commonButtonSEL:@selector(changeFont:) target:self];
        [_decreaseFont setTitle:@"A-" forState:UIControlStateNormal];
        [_decreaseFont.titleLabel setFont:[UIFont systemFontOfSize:17]];
        _decreaseFont.layer.borderWidth = 1;
        _decreaseFont.layer.borderColor = [UIColor whiteColor].CGColor;
    }
    return _decreaseFont;
}
-(UILabel *)fontLabel
{
    if (!_fontLabel) {
        _fontLabel = [[UILabel alloc] init];
        _fontLabel.font = [UIFont systemFontOfSize:14];
        _fontLabel.textColor = [UIColor whiteColor];
        _fontLabel.textAlignment = NSTextAlignmentCenter;
        _fontLabel.text = [NSString stringWithFormat:@"%d",(int)[RXReadConfig shareInstance].fontSize];
    }
    return _fontLabel;
}
-(RXThemView *)themeView
{
    if (!_themeView) {
        _themeView = [[RXThemView alloc] init];
    }
    return _themeView;
}

#pragma mark - Button Click
-(void)jumpChapter:(UIButton *)sender
{
    if (sender == _nextChapter) {
        if ([self.delegate respondsToSelector:@selector(menuViewJumpChapter:isNextChapter:)]) {
            [self.delegate menuViewJumpChapter:self isNextChapter:YES];
        }
    }
    else{
        if ([self.delegate respondsToSelector:@selector(menuViewJumpChapter:isNextChapter:)]) {
            [self.delegate menuViewJumpChapter:self isNextChapter:NO];
        }
        
    }
}
-(void)changeFont:(UIButton *)sender
{
    
    if (sender == _increaseFont) {
        
        if (floor([RXReadConfig shareInstance].fontSize) == floor(MaxFontSize)) {
            return;
        }
        [RXReadConfig shareInstance].fontSize++;
    }
    else{
        if (floor([RXReadConfig shareInstance].fontSize) == floor(MinFontSize)){
            return;
        }
        [RXReadConfig shareInstance].fontSize--;
    }
    
    if ([self.delegate respondsToSelector:@selector(menuViewFontSize:)]) {
        [self.delegate menuViewFontSize:self];
    }
}
#pragma mark showMsg

-(void)changeMsg:(UISlider *)sender
{
    if ([self.delegate respondsToSelector:@selector(menuViewJumpChapter:sliderValue:)]) {
        [self.delegate menuViewJumpChapter:self sliderValue:sender.value];
    }
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context
{
    
    if ([keyPath isEqualToString:@"chapterModel.chapter"] || [keyPath isEqualToString:@"chapterModel.page"]) {
       
    }
    else if ([keyPath isEqualToString:@"fontSize"]){
        _fontLabel.text = [NSString stringWithFormat:@"%d",(int)[RXReadConfig shareInstance].fontSize];
    }
    else{
        if (_slider.state == UIControlStateNormal) {
            _progressView.hidden = YES;
        }
        else if(_slider.state == UIControlStateHighlighted){
            _progressView.hidden = NO;
        }
    }
    
}
-(UIImage *)thumbImage
{
    CGRect rect = CGRectMake(0, 0, 15,15);
    UIBezierPath *path = [UIBezierPath bezierPath];
    path.lineWidth = 5;
    [path addArcWithCenter:CGPointMake(rect.size.width/2, rect.size.height/2) radius:7.5 startAngle:0 endAngle:2*M_PI clockwise:YES];
    
    UIImage *image = nil;
    UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0);
    {
        [[UIColor whiteColor] setFill];
        [path fill];
        image = UIGraphicsGetImageFromCurrentImageContext();
    }
    UIGraphicsEndImageContext();
    return image;
}
-(void)showCatalog
{
    if ([self.delegate respondsToSelector:@selector(menuViewInvokeCatalog:)]) {
        [self.delegate menuViewInvokeCatalog:self];
    }
}
-(void)layoutSubviews
{
    [super layoutSubviews];
    _slider.frame = CGRectMake(50, 20, self.mp_width-100, 30);
    _lastChapter.frame = CGRectMake(5, 20, 40, 30);
    _nextChapter.frame = CGRectMake(self.slider.mp_origin.x + self.slider.mp_width + 5, 20, 40, 30);
    _decreaseFont.frame = CGRectMake(10,self.slider.mp_origin.y + self.slider.mp_height + 10, (self.mp_width - 20)/3, 30);
    _fontLabel.frame = CGRectMake(self.decreaseFont.mp_origin.x + self.decreaseFont.mp_width, self.slider.mp_origin.y + self.slider.mp_height + 10, (self.mp_width - 20)/3,  30);
    _increaseFont.frame = CGRectMake(self.fontLabel.mp_origin.x + self.fontLabel.mp_width, self.slider.mp_origin.y + self.slider.mp_height+10,  (self.mp_width-20)/3, 30);
    _themeView.frame = CGRectMake(0, self.increaseFont.mp_origin.y + self.increaseFont.mp_height+10, self.mp_width, 40);
    _catalog.frame = CGRectMake(10, self.themeView.mp_origin.y + self.themeView.mp_height, 30, 30);
    _progressView.frame = CGRectMake(60, -60, self.mp_width - 120, 50);
    
}

-(void)dealloc
{
    [_slider removeObserver:self forKeyPath:@"highlighted"];
    [[RXReadConfig shareInstance] removeObserver:self forKeyPath:@"fontSize"];
}
@end
