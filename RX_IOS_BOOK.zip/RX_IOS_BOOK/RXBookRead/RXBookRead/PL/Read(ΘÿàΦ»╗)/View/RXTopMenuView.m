//
//  RXTopMenuView.m
//  RXBookRead
//
//  Created by Evan on 2018/6/4.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXTopMenuView.h"

@interface RXTopMenuView()
@property (nonatomic,strong) UIButton *backButton;
@end

@implementation RXTopMenuView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setup];
    }
    return self;
}

-(void)setup
{
    [self setBackgroundColor:RXColor(0, 0, 0, 0.8)];
    [self addSubview:self.backButton];
}

- (void)backView{
    [[RXUtilites getCurrentVC] dismissViewControllerAnimated:YES completion:nil];
}

-(UIButton *)backButton
{
    if (!_backButton) {
        _backButton = [RXUtilites commonButtonSEL:@selector(backView) target:self];
        _backButton.frame = CGRectMake(0,15 + HEIGHT_NAVADD_FIT, 40, 40);
        [_backButton setImage:[UIImage imageNamed:@"bg_back_white"] forState:UIControlStateNormal];
        
    }
    return _backButton;
}
@end
