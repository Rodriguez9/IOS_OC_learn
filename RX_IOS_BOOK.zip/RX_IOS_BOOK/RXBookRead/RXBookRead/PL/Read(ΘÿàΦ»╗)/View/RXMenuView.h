//
//  RXMenuView.h
//  RXBookRead
//
//  Created by Evan on 2018/6/4.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RXTopMenuView.h"
#import "RXBottomMenuView.h"
#import "RXChapterModel.h"

@class RXMenuView,RXBottomMenuView;

@protocol RXMenuViewDelegate <NSObject>
@optional
-(void)menuViewDidHidden:(RXMenuView *)menu;
-(void)menuViewDidAppear:(RXMenuView *)menu;
-(void)menuViewInvokeCatalog:(RXBottomMenuView *)bottomMenu;
-(void)menuViewJumpChapter:(RXBottomMenuView *)bottomMenu isNextChapter:(BOOL)isNextChapter;
-(void)menuViewJumpChapter:(RXBottomMenuView *)bottomMenu sliderValue:(float)sliderValue;
-(void)menuViewFontSize:(RXBottomMenuView *)bottomMenu;
//-(void)menuViewMark:(LSYTopMenuView *)topMenu;
@end

@interface RXMenuView : UIView
@property (nonatomic,weak) id<RXMenuViewDelegate>delegate;
@property (nonatomic, strong) RXTopMenuView *topView;
@property (nonatomic, strong) RXBottomMenuView *bottomView;
@property (nonatomic, strong) RXChapterModel *chapterModel;
-(void)showAnimation:(BOOL)animation;
-(void)hiddenAnimation:(BOOL)animation;
@end
