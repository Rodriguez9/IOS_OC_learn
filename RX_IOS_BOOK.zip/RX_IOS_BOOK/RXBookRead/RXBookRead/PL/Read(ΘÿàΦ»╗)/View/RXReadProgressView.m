//
//  RXReadProgressView.m
//  RXBookRead
//
//  Created by Evan on 2018/6/4.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXReadProgressView.h"
#import "RXReadConfig.h"

@interface RXReadProgressView()
@property (nonatomic,strong) UILabel *label;
@end

@implementation RXReadProgressView

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setBackgroundColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:0.8]];
        [self addSubview:self.label];
    }
    return self;
}
-(UILabel *)label
{
    if (!_label) {
        _label = [[UILabel alloc] init];
        _label.font = [UIFont systemFontOfSize:[RXReadConfig shareInstance].fontSize];
        _label.textColor = [UIColor whiteColor];
        _label.textAlignment = NSTextAlignmentCenter;
        _label.numberOfLines = 0;
    }
    return _label;
}
-(void)progress:(NSString *)progress
{
    _label.text = [NSString stringWithFormat:@"%@",progress];
}
-(void)layoutSubviews
{
    [super layoutSubviews];
    _label.frame = self.bounds;
}

@end
