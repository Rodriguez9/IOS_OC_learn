//
//  RXMenuView.m
//  RXBookRead
//
//  Created by Evan on 2018/6/4.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXMenuView.h"

@interface RXMenuView()<RXMenuViewDelegate>

@end

@implementation RXMenuView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setup];
    }
    return self;
}
-(void)setup
{
    self.backgroundColor = [UIColor clearColor];
    [self addSubview:self.topView];
    [self addSubview:self.bottomView];
    [self addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hiddenSelf)]];
}

- (void)setChapterModel:(RXChapterModel *)chapterModel{
    _chapterModel = chapterModel;
    self.bottomView.chapterModel = chapterModel;
}
-(void)hiddenSelf
{
    [self hiddenAnimation:YES];
}

-(void)showAnimation:(BOOL)animation
{
    self.hidden = NO;
    [UIView animateWithDuration:animation?0.3:0 animations:^{
        self.topView.frame = CGRectMake(0, 0, self.mp_width, HEIGHT_NAV_FIT);
        self.bottomView.frame = CGRectMake(0, self.mp_height - 200, self.mp_width,200);
    } completion:^(BOOL finished) {
        
    }];
    if ([self.delegate respondsToSelector:@selector(menuViewDidAppear:)]) {
        [self.delegate menuViewDidAppear:self];
    }
}

-(void)hiddenAnimation:(BOOL)animation
{
    
    [UIView animateWithDuration:animation?0.3:0 animations:^{
        self.topView.frame = CGRectMake(0, -HEIGHT_NAV_FIT, self.mp_width, HEIGHT_NAV_FIT);
        self.bottomView.frame = CGRectMake(0, self.mp_height, self.mp_width,200);
    } completion:^(BOOL finished) {
        self.hidden = YES;
    }];
    if ([self.delegate respondsToSelector:@selector(menuViewDidHidden:)]) {
        [self.delegate menuViewDidHidden:self];
    }
}

-(void)menuViewFontSize:(RXBottomMenuView *)bottomMenu
{
    if ([self.delegate respondsToSelector:@selector(menuViewFontSize:)]) {
        [self.delegate menuViewFontSize:bottomMenu];
    }
}

- (void)menuViewJumpChapter:(RXBottomMenuView *)bottomMenu isNextChapter:(BOOL)isNextChapter{
    if ([self.delegate respondsToSelector:@selector(menuViewJumpChapter:isNextChapter:)]) {
        [self.delegate menuViewJumpChapter:bottomMenu isNextChapter:isNextChapter];
    }
}

-(void)menuViewInvokeCatalog:(RXBottomMenuView *)bottomMenu
{
    if ([self.delegate respondsToSelector:@selector(menuViewInvokeCatalog:)]) {
        [self.delegate menuViewInvokeCatalog:bottomMenu];
    }
}

- (void)menuViewJumpChapter:(RXBottomMenuView *)bottomMenu sliderValue:(float)sliderValue{
    if ([self.delegate respondsToSelector:@selector(menuViewJumpChapter:sliderValue:)]) {
        [self.delegate menuViewJumpChapter:bottomMenu sliderValue:sliderValue];
    }
}
-(RXTopMenuView *)topView
{
    if (!_topView) {
        _topView = [[RXTopMenuView alloc] initWithFrame:CGRectMake(0, -HEIGHT_NAV_FIT,self.mp_width,HEIGHT_NAV_FIT)];
        _topView.delegate = self;
    }
    return _topView;
}

-(RXBottomMenuView *)bottomView
{
    if (!_bottomView) {
        _bottomView = [[RXBottomMenuView alloc] initWithFrame:CGRectMake(0, self.mp_height, self.mp_width,200)];
        _bottomView.delegate = self;
    }
    return _bottomView;
}
@end
