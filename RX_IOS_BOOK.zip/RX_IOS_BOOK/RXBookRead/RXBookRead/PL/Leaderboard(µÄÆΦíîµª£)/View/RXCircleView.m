//
//  RXCircleView.m
//  RXBookRead
//
//  Created by Evan on 2018/5/30.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXCircleView.h"

@implementation RXCircleView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    [self setNeedsDisplay];
}
- (void)setColor:(UIColor *)color{
    _color = color;
     [self setNeedsDisplay];
}
- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    
    CGRect frame = CGRectMake(0, 0, 4, 4);
    CGContextRef context = UIGraphicsGetCurrentContext();
    [[UIColor whiteColor] set];
    CGContextFillRect(context, rect);
    
    CGContextAddEllipseInRect(context, frame);
    [self.color set];
    CGContextFillPath(context);
    
}

@end
