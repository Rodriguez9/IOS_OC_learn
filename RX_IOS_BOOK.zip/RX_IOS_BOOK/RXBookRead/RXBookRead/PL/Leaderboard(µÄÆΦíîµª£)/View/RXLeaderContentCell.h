//
//  RXLeaderContentCell.h
//  RXBookRead
//
//  Created by Evan on 2018/5/30.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXTableViewCell.h"


@class RXLeaderContentDetailModel;
@interface RXLeaderContentCell : RXTableViewCell
@property (nonatomic, strong) RXLeaderContentDetailModel *leaderContentModel;
@end
