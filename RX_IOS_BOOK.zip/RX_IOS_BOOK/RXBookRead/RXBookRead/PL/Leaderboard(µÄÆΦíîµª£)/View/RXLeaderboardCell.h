//
//  RXLeaderboardCell.h
//  RXBookRead
//
//  Created by Evan on 2018/5/30.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXTableViewCell.h"

@class RXLeaderboardDetailModel;
@interface RXLeaderboardCell : RXTableViewCell
@property (nonatomic, strong) RXLeaderboardDetailModel *leaderDetailModel;
@end
