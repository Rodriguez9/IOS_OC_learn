//
//  RXLeaderboardCell.m
//  RXBookRead
//
//  Created by Evan on 2018/5/30.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXLeaderboardCell.h"
#import "RXLeaderboardModel.h"
#import "RXCircleView.h"

@interface RXLeaderboardCell()

@property (nonatomic, weak) UIImageView *iconView;

@property (nonatomic, weak) UILabel *titleLabel;

@property (nonatomic, weak) UILabel *book1Label;

@property (nonatomic, weak) UILabel *book2Label;

@property (nonatomic, weak) UILabel *book3Label;

@property (nonatomic, weak) RXCircleView *circleView1;

@property (nonatomic, weak) RXCircleView *circleView2;

@property (nonatomic, weak) RXCircleView *circleView3;

@end

@implementation RXLeaderboardCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        [self setupUI];
    }
    return self;
}



- (void)setLeaderDetailModel:(RXLeaderboardDetailModel *)leaderDetailModel{
    _leaderDetailModel = leaderDetailModel;
    //图片
     NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",IMAGE_PRE,leaderDetailModel.coverImgUrl]];
    [self.iconView sd_setImageWithURL:url];
    
    //标题
    self.titleLabel.text = leaderDetailModel.rankName;
    
    //排名前三的书
    NSArray *bookNameArr = [leaderDetailModel.book_name compomentString];
    self.book1Label.text = bookNameArr.firstObject;
    self.book2Label.text = [bookNameArr rx_objectAtIndex:1];
    self.book3Label.text = [bookNameArr rx_objectAtIndex:2];
}
- (void)setupUI{
    //图片
    UIImageView *iconView = [[UIImageView alloc] init];
    [self.contentView addSubview:iconView];
    self.iconView = iconView;
    
    //标题
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.font = [UIFont systemFontOfSize:16];
    titleLabel.textColor = [UIColor blackColor];
    [self.contentView addSubview:titleLabel];
    self.titleLabel = titleLabel;
    
    //第一名的书
    UILabel *book1Label = [[UILabel alloc] init];
    book1Label.font = [UIFont systemFontOfSize:13];
    book1Label.textColor = [UIColor lightGrayColor];
    [self.contentView addSubview:book1Label];
    self.book1Label= book1Label;
    
    RXCircleView *circleView1 = [[RXCircleView alloc] init];
    circleView1.color = [UIColor redColor];
    [self.contentView addSubview:circleView1];
    self.circleView1 = circleView1;
    
    //第二名的书
    UILabel *book2Label = [[UILabel alloc] init];
    book2Label.font = [UIFont systemFontOfSize:13];
    book2Label.textColor = [UIColor lightGrayColor];
    [self.contentView addSubview:book2Label];
    self.book2Label = book2Label;
   
    
    RXCircleView *circleView2 = [[RXCircleView alloc] init];
    circleView2.color = [UIColor lightGrayColor];
    [self.contentView addSubview:circleView2];
    self.circleView2 = circleView2;
    
    //第三名的书
    UILabel *book3Label = [[UILabel alloc] init];
    book3Label.font = [UIFont systemFontOfSize:13];
    book3Label.textColor = [UIColor lightGrayColor];
    [self.contentView addSubview:book3Label];
    self.book3Label = book3Label;
    
    RXCircleView *circleView3 = [[RXCircleView alloc] init];
    circleView3.color = [UIColor lightGrayColor];
    [self.contentView addSubview:circleView3];
    self.circleView3 = circleView3;
    
    [self setConstraints];
}

- (void)setConstraints{
    [self.iconView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView).offset(20);
        make.top.equalTo(self.contentView).offset(20);
        make.size.mas_equalTo(CGSizeMake(60, 80));
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.iconView.mas_right).offset(20);
        make.top.equalTo(self.iconView).offset(5);
        make.right.equalTo(self.contentView).offset(-30);
    }];
    
    [self.book1Label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.iconView.mas_right).offset(28);
        make.right.equalTo(self.contentView).offset(-30);
        make.top.equalTo(self.titleLabel.mas_bottom).offset(5);
    }];
    
    [self.circleView1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.iconView.mas_right).offset(20);
        make.centerY.equalTo(self.book1Label);
        make.size.mas_equalTo(CGSizeMake(4, 4));
    }];
    
    [self.book2Label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.iconView.mas_right).offset(28);
        make.right.equalTo(self.contentView).offset(-30);
        make.top.equalTo(self.book1Label.mas_bottom).offset(5);
    }];
    
    [self.circleView2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.iconView.mas_right).offset(20);
        make.centerY.equalTo(self.book2Label);
        make.size.mas_equalTo(CGSizeMake(4, 4));
    }];
    
    [self.book3Label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.iconView.mas_right).offset(28);
        make.right.equalTo(self.contentView).offset(-30);
        make.top.equalTo(self.book2Label.mas_bottom).offset(5);
    }];
    
    [self.circleView3 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.iconView.mas_right).offset(20);
        make.centerY.equalTo(self.book3Label);
        make.size.mas_equalTo(CGSizeMake(4, 4));
    }];
}

@end
