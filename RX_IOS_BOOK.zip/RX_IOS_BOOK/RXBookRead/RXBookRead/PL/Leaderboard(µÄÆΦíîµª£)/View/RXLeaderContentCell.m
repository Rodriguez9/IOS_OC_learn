//
//  RXLeaderContentCell.m
//  RXBookRead
//
//  Created by Evan on 2018/5/30.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXLeaderContentCell.h"
#import "RXLeaderContentModel.h"

@interface RXLeaderContentCell()

@property (nonatomic, weak) UIImageView *iconView;

@property (nonatomic, weak) UILabel *titleLabel;

@property (nonatomic, weak) UILabel *authorLabel;

@property (nonatomic, weak) UILabel *descLabel;

@property (nonatomic, weak) UILabel *countLabel;
@end

@implementation RXLeaderContentCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        [self setupUI];
    }
    return self;
}

- (void)setLeaderContentModel:(RXLeaderContentDetailModel *)leaderContentModel{
    _leaderContentModel = leaderContentModel;
    
    //图片
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",IMAGE_PRE,leaderContentModel.cover]];
    [self.iconView sd_setImageWithURL:url];
    
    //标题
    self.titleLabel.text = leaderContentModel.title;
    
    //作者
    self.authorLabel.text = leaderContentModel.author;
    
    //描述
    self.descLabel.text = leaderContentModel.shortIntro;
    
    //追读数量
    self.countLabel.text = [NSString stringWithFormat:@"%lld人在追|%.2f%%读者留存",leaderContentModel.latelyFollower,leaderContentModel.retentionRatio];
}
- (void)setupUI{
    //图片
    UIImageView *iconView = [[UIImageView alloc] init];
    [self.contentView addSubview:iconView];
    self.iconView = iconView;
    
    //标题
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.font = [UIFont systemFontOfSize:16];
    titleLabel.textColor = [UIColor blackColor];
    [self.contentView addSubview:titleLabel];
    self.titleLabel = titleLabel;
    
    //作者
    UILabel *authorLabel = [[UILabel alloc] init];
    authorLabel.font = [UIFont systemFontOfSize:13];
    authorLabel.textColor = [UIColor darkGrayColor];
    [self.contentView addSubview:authorLabel];
    self.authorLabel= authorLabel;
    
    //描述
    UILabel *descLabel = [[UILabel alloc] init];
    descLabel.font = [UIFont systemFontOfSize:13];
    descLabel.textColor = [UIColor darkGrayColor];
    [self.contentView addSubview:descLabel];
    self.descLabel = descLabel;
    
    //追书量
    UILabel *countLabel = [[UILabel alloc] init];
    countLabel.font = [UIFont systemFontOfSize:13];
    countLabel.textColor = [UIColor lightGrayColor];
    [self.contentView addSubview:countLabel];
    self.countLabel = countLabel;
    
    [self setConstraints];
}

- (void)setConstraints{
    [self.iconView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView).offset(15);
        make.top.equalTo(self.contentView).offset(25);
        make.size.mas_equalTo(CGSizeMake(50, 60));
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.iconView.mas_right).offset(15);
        make.top.equalTo(self.contentView).offset(15);
        make.right.equalTo(self.contentView).offset(-20);
    }];
    
    [self.authorLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.iconView.mas_right).offset(15);
        make.right.equalTo(self.contentView).offset(-20);
        make.top.equalTo(self.titleLabel.mas_bottom).offset(5);
    }];
    
    [self.descLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.iconView.mas_right).offset(15);
        make.right.equalTo(self.contentView).offset(-20);
        make.top.equalTo(self.authorLabel.mas_bottom).offset(5);
    }];
    
    [self.countLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.iconView.mas_right).offset(15);
        make.right.equalTo(self.contentView).offset(-20);
        make.top.equalTo(self.descLabel.mas_bottom).offset(5);
    }];
}
@end
