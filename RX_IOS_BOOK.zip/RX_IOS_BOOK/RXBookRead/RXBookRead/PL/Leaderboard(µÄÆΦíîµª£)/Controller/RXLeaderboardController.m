//
//  RXLeaderboardController.m
//  RXBookRead
//
//  Created by Evan on 2018/5/29.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXLeaderboardController.h"
#import "RXLeaderboardModel.h"
#import "RXLeaderboardCell.h"
#import "RXLeaderContentController.h"
#import "RXSearchController.h"

#define cellIdentifier @"lasderboardCell"
@interface RXLeaderboardController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic, weak) RXTableView *tableView;
@property (nonatomic, strong) NSArray *leaderboards;

@end

@implementation RXLeaderboardController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.title = @"排行榜";
    
    [self.view addSubview:self.tableView];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"nav_searchBtn"] style:UIBarButtonItemStylePlain target:self action:@selector(gotoSearchController)];
    
    [self.tableView registerClass:[RXLeaderboardCell class] forCellReuseIdentifier:cellIdentifier];
    //设置刷新控件
    [self setupRefresh];
}

- (void)setupRefresh{
    // 创建刷新控件
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadData)];
    
    // 自动改变透明度
    self.tableView.mj_header.automaticallyChangeAlpha = YES;
    // 立刻刷新
    [self.tableView.mj_header beginRefreshing];
}

#pragma mark - 加载数据
- (void)loadData{
    RXWeakSelf(self);
    [RXAPIManager getNovelLeaderboardSuccess:^(RXLeaderboardModel *leaderboardModel) {
        [weakself.tableView.mj_header endRefreshing];
        weakself.leaderboards = leaderboardModel.item;
        [weakself.tableView reloadData];
    } failure:^(NSError *error) {
         [weakself.tableView.mj_header endRefreshing];
    }];
}
#pragma mark - 数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.leaderboards.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    RXLeaderboardDetailModel *leaderDetailModel = [self.leaderboards rx_objectAtIndex:indexPath.row];

    RXLeaderboardCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];

    cell.leaderDetailModel = leaderDetailModel;

    return cell;
}

//- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//     RXLeaderboardDetailModel *leaderDetailModel = [self.leaderboards rx_objectAtIndex:indexPath.row];
//
//    RXLeaderContentController *contentVc = [[RXLeaderContentController alloc] init];
//    contentVc.hidesBottomBarWhenPushed = YES;
//    contentVc.rankingId = leaderDetailModel.rankid;
//    contentVc.rankName = leaderDetailModel.rankName;
//    [self.navigationController pushViewController:contentVc animated:YES];
//
//}

//- (void)gotoSearchController{
//    RXSearchController *searchVc = [[RXSearchController alloc] init];
//    searchVc.hidesBottomBarWhenPushed = YES;
//    [self.navigationController pushViewController:searchVc animated:YES];
//}

- (RXTableView *)tableView {
    if (!_tableView) {
        RXTableView *tableView = [[RXTableView alloc] initWithFrame:self.view.bounds];
        [tableView setBackgroundColor:[UIColor whiteColor]];
        tableView.delegate = self;
        tableView.rowHeight = 120;
        tableView.dataSource = self;
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
        [self.view addSubview:tableView];
        _tableView = tableView;
    }
    return _tableView;
}

//- (NSArray *)leaderboards{
//    if (!_leaderboards) {
//        _leaderboards = [NSArray array];
//    }
//    return _leaderboards;
//}
@end
