//
//  RXLeaderContentController.h
//  RXBookRead
//
//  Created by Evan on 2018/5/30.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXBaseController.h"

@interface RXLeaderContentController : RXBaseController
@property (nonatomic, copy) NSString *rankingId;
@property (nonatomic, copy) NSString *rankName;
@end
