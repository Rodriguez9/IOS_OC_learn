//
//  RXCategoryBookListController.m
//  RXBookRead
//
//  Created by Evan on 2018/6/1.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXCategoryBookListController.h"
#import "RXLeaderContentCell.h"
#import "RXLeaderContentModel.h"
#import "RXBookDetailController.h"

#define cellIdentifier @"categoryBookCell"
@interface RXCategoryBookListController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic, weak) RXTableView *tableView;
@property (nonatomic, strong) NSArray *categoryBookList;
@end

@implementation RXCategoryBookListController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = self.major;
    
    [self.view addSubview:self.tableView];
    
    [self.tableView registerClass:[RXLeaderContentCell class] forCellReuseIdentifier:cellIdentifier];
    //设置刷新控件
    [self setupRefresh];
}

- (void)setupRefresh{
    // 创建刷新控件
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadData)];
    
    // 自动改变透明度
    self.tableView.mj_header.automaticallyChangeAlpha = YES;
    // 立刻刷新
    [self.tableView.mj_header beginRefreshing];
}

- (void)loadData{
    RXWeakSelf(self);
    [RXAPIManager getCategotyBookListWithMajor:self.major success:^(RXLeaderContentModel *categoryBookModel) {
        [weakself.tableView.mj_header endRefreshing];
        weakself.categoryBookList = categoryBookModel.books;
        [weakself.tableView reloadData];
    } failure:^(NSError *error) {
        [weakself.tableView.mj_header endRefreshing];
    }];
}

#pragma mark - 数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.categoryBookList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    RXLeaderContentDetailModel *leaderContentModel = [self.categoryBookList rx_objectAtIndex:indexPath.row];
    
    RXLeaderContentCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    cell.leaderContentModel = leaderContentModel;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    RXLeaderContentDetailModel *leaderContentModel = [self.categoryBookList rx_objectAtIndex:indexPath.row];
    RXBookDetailController *bookDetailVc = [[RXBookDetailController alloc] init];
    bookDetailVc.bookId = leaderContentModel.ID;
    [self.navigationController pushViewController:bookDetailVc animated:YES];
}

- (RXTableView *)tableView {
    if (!_tableView) {
        RXTableView *tableView = [[RXTableView alloc] initWithFrame:self.view.bounds];
        [tableView setBackgroundColor:[UIColor whiteColor]];
        tableView.delegate = self;
        tableView.rowHeight = 110;
        tableView.dataSource = self;
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
        [self.view addSubview:tableView];
        _tableView = tableView;
    }
    return _tableView;
}

- (NSArray *)categoryBookList{
    if (!_categoryBookList) {
        _categoryBookList = [NSArray array];
    }
    return _categoryBookList;
}
@end
