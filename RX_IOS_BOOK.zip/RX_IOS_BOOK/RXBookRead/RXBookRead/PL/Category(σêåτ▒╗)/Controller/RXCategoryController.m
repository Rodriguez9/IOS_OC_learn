//
//  RXCategoryController.m
//  RXBookRead
//
//  Created by Evan on 2018/5/29.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXCategoryController.h"
#import "RXCategoryModel.h"
#import "RXCategoryBookListController.h"
#import "RXCategoryCell.h"
#import "RXSearchController.h"

#define cellIdentifier @"categoryCell"
@interface RXCategoryController ()
//@property (nonatomic, weak) RXTableView *tableView;
@property (nonatomic, strong) NSArray *categories;
@end

@implementation RXCategoryController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"分类";
    
    self.collectionView.backgroundColor = [UIColor whiteColor];
    self.collectionView.showsVerticalScrollIndicator = NO;
    [self.collectionView registerClass:[RXCategoryCell class] forCellWithReuseIdentifier:cellIdentifier];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"nav_searchBtn"] style:UIBarButtonItemStylePlain target:self action:@selector(gotoSearchController)];
    
    [self loadData];
   
}

- (void)loadData{
    RXWeakSelf(self);
    [RXAPIManager getBookCategotySuccess:^(RXCategoryModel *categoryModel) {
        weakself.categories = categoryModel.male;
        [weakself.collectionView reloadData];
    } failure:^(NSError *error) {
        
    }];
}

- (void)gotoSearchController{
    RXSearchController *searchVc = [[RXSearchController alloc] init];
    searchVc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:searchVc animated:YES];
}

- (instancetype)init{
    // 1.流水布局
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    // 2.每个cell的尺寸
    layout.itemSize =  CGSizeMake((WIDTH_SCREEN - 100)/3, 160);
    // 3.设置cell之间的水平间距
    layout.minimumInteritemSpacing = 10;
    layout.minimumLineSpacing = 20;
    [layout setSectionInset:UIEdgeInsetsMake(20, 20, 20, 20)];
    return [super initWithCollectionViewLayout:layout];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.categories.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    // 1.获得cell
    RXCategoryCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];
    
    RXCategoryDetailModel *categoryDetailModel = [self.categories rx_objectAtIndex:indexPath.item];
    
    cell.model = categoryDetailModel;
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    RXCategoryDetailModel *categoryDetailModel = [self.categories rx_objectAtIndex:indexPath.item];
    RXCategoryBookListController *bookListVc = [[RXCategoryBookListController alloc] init];
    bookListVc.hidesBottomBarWhenPushed = YES;
    bookListVc.major = categoryDetailModel.name;
    [self.navigationController pushViewController:bookListVc animated:YES];
}

//#pragma mark - 数据源方法
//- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
//    return self.categories.count;
//}
//
//- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
//    RXCategoryDetailModel *categoryDetailModel = [self.categories rx_objectAtIndex:indexPath.row];
//
//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
//
//    cell.textLabel.text = categoryDetailModel.name;
//
//    return cell;
//}
//
//- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//     [tableView deselectRowAtIndexPath:indexPath animated:NO];
//     RXCategoryDetailModel *categoryDetailModel = [self.categories rx_objectAtIndex:indexPath.row];
//    RXCategoryBookListController *bookListVc = [[RXCategoryBookListController alloc] init];
//    bookListVc.hidesBottomBarWhenPushed = YES;
//    bookListVc.major = categoryDetailModel.name;
//    [self.navigationController pushViewController:bookListVc animated:YES];
//}

//- (RXTableView *)tableView {
//    if (!_tableView) {
//        RXTableView *tableView = [[RXTableView alloc] initWithFrame:self.view.bounds];
//        [tableView setBackgroundColor:[UIColor whiteColor]];
//        tableView.delegate = self;
//        tableView.rowHeight = 44;
//        tableView.dataSource = self;
//        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
//        [self.view addSubview:tableView];
//        _tableView = tableView;
//    }
//    return _tableView;
//}

- (NSArray *)categories{
    if (!_categories) {
        _categories = [NSArray array];
    }
    return _categories;
}
@end
