//
//  RXCategoryBookListController.h
//  RXBookRead
//
//  Created by Evan on 2018/6/1.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXBaseController.h"

@interface RXCategoryBookListController : RXBaseController
@property (nonatomic, copy) NSString *major;
@end
