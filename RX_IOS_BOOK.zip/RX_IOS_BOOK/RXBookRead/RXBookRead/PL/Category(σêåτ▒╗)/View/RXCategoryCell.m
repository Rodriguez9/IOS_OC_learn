//
//  RXCategoryCell.m
//  RXBookRead
//
//  Created by Evan on 2018/6/13.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXCategoryCell.h"

@interface RXCategoryCell()
@property (nonatomic, weak) UIImageView *iconView;
@property (nonatomic, weak) UILabel *titleLabel;
@end

@implementation RXCategoryCell

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
        [self setupUI];
    }
    return self;
}

- (void)setModel:(RXCategoryDetailModel *)model{
    _model = model;
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",IMAGE_PRE,model.bookCover.lastObject]];
    [self.iconView sd_setImageWithURL:url];
  
    self.titleLabel.text = model.name;
}
- (void)setupUI{
    UIImageView *iconView = [[UIImageView alloc] init];
    [self.contentView addSubview:iconView];
    self.iconView = iconView;
    
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.font = [UIFont systemFontOfSize:14];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.contentView addSubview:titleLabel];
    self.titleLabel = titleLabel;
    
    [self setupConstraints];
}

- (void)setupConstraints{
    [self.iconView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.equalTo(self.contentView);
        make.bottom.equalTo(self).offset(-30);
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.right.equalTo(self.contentView);
        make.height.mas_equalTo(20);
    }];
}
@end
