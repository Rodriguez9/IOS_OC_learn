//
//  RXCategoryCell.h
//  RXBookRead
//
//  Created by Evan on 2018/6/13.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RXCategoryModel.h"

@interface RXCategoryCell : UICollectionViewCell
@property (nonatomic, strong) RXCategoryDetailModel *model;
@end
