//
//  RXDisclaimerController.m
//  RXBookRead
//
//  Created by Evan on 2018/6/14.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXDisclaimerController.h"

@interface RXDisclaimerController ()
@property (nonatomic, strong) UITextView *textView;
@end

@implementation RXDisclaimerController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"用户协议";
    [self.view addSubview:self.textView];
    NSString *path = [[NSBundle mainBundle] pathForResource:@"协议.plist" ofType:nil];
    NSString *str = [NSDictionary dictionaryWithContentsOfFile:path][@"协议"];
    NSString *text = [str stringByReplacingOccurrencesOfString:@"/n" withString:@"\n"];
    self.textView.text = text;
}

- (UITextView *)textView{
    if (!_textView) {
        _textView = [[UITextView alloc] initWithFrame:CGRectMake(0, HEIGHT_NAV_FIT, WIDTH_SCREEN, HEIGHT_SCREEN - HEIGHT_NAV_FIT)];
        _textView.editable = NO;
        _textView.font = [UIFont systemFontOfSize:14];
    }
    return _textView;
}
@end
