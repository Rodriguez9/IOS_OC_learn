//
//  RXDisclaimerController.h
//  RXBookRead
//
//  Created by Evan on 2018/6/14.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXBaseController.h"

@interface RXDisclaimerController : RXBaseController

@end
