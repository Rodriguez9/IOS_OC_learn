//
//  RXMoreController.m
//  RXBookRead
//
//  Created by Evan on 2018/5/29.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXMoreController.h"
#import "RXTableViewCell.h"
#import "RXDisclaimerController.h"

#define cellIdentifier @"moreCell"
@interface RXMoreController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic, weak) RXTableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataSource;
@property (nonatomic, strong) NSFileManager *fileManager;
@end

@implementation RXMoreController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"更多";
    
    [self.view addSubview:self.tableView];
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:2 inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
}
#pragma mark - 数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 4;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *title = [self.dataSource rx_objectAtIndex:indexPath.row];
    
    RXTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (!cell) {
        cell = [[RXTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellIdentifier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.textLabel.font = [UIFont systemFontOfSize:15];
    cell.textLabel.text = title;
    
    if (indexPath.row > 0) {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        if (indexPath.row == 2) {
            cell.detailTextLabel.text = [self getCacheNumber];
        }else if (indexPath.row == 3){
            cell.detailTextLabel.text = Contact_US;
        }
    }else{
        cell.detailTextLabel.text = [NSString stringWithFormat:@"V%@",APP_VERSION];
    }
   
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    RXWeakSelf(self);
    if (indexPath.row == 1) {
        RXDisclaimerController *disVc = [[RXDisclaimerController alloc] init];
        disVc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:disVc animated:YES];
    }else if (indexPath.row == 2) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:@"要清楚缓存吗？" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *action = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:nil];
        
        UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [[SDImageCache sharedImageCache] clearDiskOnCompletion:^{
                [weakself cleanCache];
            }];
        }];
        
        [alert addAction:action];
        [alert addAction:action1];
        [self presentViewController:alert animated:YES completion:nil];
    }
    
}

- (NSString *)getCacheNumber{
//    NSDictionary<NSString *, id> *attrs = [self.fileManager attributesOfItemAtPath:Cache_Path error:nil];
    float num = (float)[[SDImageCache sharedImageCache] getSize];
    return [NSString stringWithFormat:@"%.1fM",num/1024.0f/1024.0f];
}

- (void)cleanCache{
    // 清理硬盘缓存
    [[SDImageCache sharedImageCache] clearMemory];
    [[iToast makeText:@"清除存成功"] show];
    [self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:2 inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
}

- (NSFileManager *)fileManager{
    if (!_fileManager) {
        _fileManager = [NSFileManager defaultManager];
    }
    return _fileManager;
}

- (NSMutableArray *)dataSource{
    if (!_dataSource) {
        _dataSource = [NSMutableArray arrayWithObjects:@"当前版本",@"用户协议",@"清楚缓存",@"联系我们", nil];
    }
    return _dataSource;
}
- (RXTableView *)tableView {
    if (!_tableView) {
        RXTableView *tableView = [[RXTableView alloc] initWithFrame:self.view.bounds];
        [tableView setBackgroundColor:[UIColor whiteColor]];
        tableView.delegate = self;
        tableView.rowHeight = 50;
        tableView.dataSource = self;
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
        [self.view addSubview:tableView];
        _tableView = tableView;
    }
    return _tableView;
}
@end
