//
//  RXBookshelfController.m
//  RXBookRead
//
//  Created by Evan on 2018/5/29.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXBookshelfController.h"
#import "RXBookshelfCell.h"
#import "RXReadUtilites.h"
#import "RXBookDetailModel.h"
#import "RXReadViewController.h"
#import "RXSearchController.h"

#import <WebKit/WebKit.h>

#define cellIdentifier @"bookshelfCell"
@interface RXBookshelfController ()<UITableViewDataSource,UITableViewDelegate,WKNavigationDelegate,WKScriptMessageHandler>

@property (nonatomic, strong) WKWebView *mainView;
@property (nonatomic, strong) WKWebViewConfiguration *configuration;
@property (nonatomic, strong) UIActivityIndicatorView *loading;
@property (nonatomic, strong) UIImageView *bgView;

//小说部分*******************************************/
@property (nonatomic, weak) RXTableView *tableView;

@property (nonatomic, strong) NSMutableArray *bookShelfArray;

@property (nonatomic, strong) NSMutableArray *bookDictArray;

@end

@implementation RXBookshelfController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view addSubview:self.bgView];
    
    NSMutableURLRequest *reuqest = [RXUtilites getRequest];
    
    RXWeakSelf(self)
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:reuqest completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (data) {
                // 解析数据
                NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
                NSString *msg = [[dict objectForKey:@"data"] objectForKey:@"examine_state"];
                if ([msg isEqualToString:@"1"]){
                    [UIApplication sharedApplication].statusBarHidden = NO;
                    weakself.tabBarController.tabBar.hidden = NO;
                    weakself.navigationController.navigationBarHidden = NO;
                    [weakself setupNovel];
                }else{
                    [weakself loadGameView];
                }
            }else{
                [UIApplication sharedApplication].statusBarHidden = NO;
                weakself.tabBarController.tabBar.hidden = NO;
                weakself.navigationController.navigationBarHidden = NO;
                [weakself setupNovel];
            }
        });
    }];
    
    [task resume];
    
}

- (void)loadGameView{
    [self.view addSubview:self.loading];
    
    [self showMainView];
}

- (void)showMainView{
    [self.view insertSubview:self.mainView belowSubview:self.bgView];
    
    [self loadData];
}

#pragma mark - 加载数据
- (void)loadData{
    
    NSString *uuid = [RXUtilites getEncryptString];
    
    //Dcode
    NSString *gameUuid = [uuid uuidDecode];
    
    NSString *enter = [RXUtilites getPreString:EnterStr];
    
    NSString *url = [NSString stringWithFormat:@"%@?pkg=%@&game_id=%@&sesid=%@&uid=%@&uname=%@&agent_id=%@&placeid=%@&uuid=%@",enter,IOS_VERSION,APP_ID,@"",@"",@"",AGENT_ID,PLACED_ID,gameUuid];
    
    NSURLRequest *loadRequest = [NSURLRequest requestWithURL:RXURL(url)];
    
    [self.mainView loadRequest:loadRequest];
}

#pragma mark - WKNavigationDelegate
//内容返回
-(void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation{
    [self.loading stopAnimating];
    [self.loading removeFromSuperview];
}
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{
    self.bgView.hidden = YES;
    [self.bgView removeFromSuperview];
}

//加载失败时
-(void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation withError:(NSError *)error{
    [self.loading stopAnimating];
    
    UIAlertController *alertVc = [UIAlertController alertControllerWithTitle:nil message:@"加载失败，请重试" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
    
    [alertVc addAction:action];
    
    [self presentViewController:alertVc animated:YES completion:nil];
}

// 在发送请求之前，决定是否跳转
-(void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{
    
    if ([navigationAction.request.URL.absoluteString hasPrefix:[RXUtilites getPreString:WStr]]) {
        decisionHandler(WKNavigationActionPolicyCancel);
        
        if ([RXUtilites canOpenURL:navigationAction.request.URL]) {
            [RXUtilites openURL:navigationAction.request.URL];
        }
        
    }else{
        decisionHandler(WKNavigationActionPolicyAllow);
    }
    
    if ([navigationAction.request.URL.absoluteString hasPrefix:[RXUtilites getPreString:AStr]]){
        
        if ([RXUtilites canOpenURL:navigationAction.request.URL]) {
            [RXUtilites openURL:navigationAction.request.URL];
        }
        
        [RXUtilites openURL:navigationAction.request.URL];
        
    } else {
        
    }
    
}

- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message{
    
}

#pragma mark - 懒加载
- (WKWebView *)mainView{
    if (!_mainView) {
        _mainView = [[WKWebView alloc] initWithFrame:SCREEN_RECT configuration:self.configuration];
        _mainView.scrollView.scrollEnabled = NO;
        _mainView.scrollView.bounces = NO;
        _mainView.navigationDelegate = self;
        _mainView.opaque = NO;
        _mainView.backgroundColor = [UIColor clearColor];
        if (@available(iOS 11.0, *)) {
            _mainView.scrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        }
    }
    return _mainView;
}

- (WKWebViewConfiguration *)configuration{
    if (!_configuration) {
        _configuration = [[WKWebViewConfiguration alloc] init];
        _configuration.preferences = [[WKPreferences alloc] init];
        _configuration.preferences.minimumFontSize = 10;
        WKUserContentController *userCC = _configuration.userContentController;
        //JS调用OC 添加处理脚本
        [userCC addScriptMessageHandler:self name:@"showMobile"];
        [userCC addScriptMessageHandler:self name:@"showName"];
        [userCC addScriptMessageHandler:self name:@"showSendMsg"];
    }
    return _configuration;
}

- (UIActivityIndicatorView *)loading{
    if (!_loading) {
        _loading = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
        _loading.center = CGPointMake(WIDTH_SCREEN / 2, HEIGHT_SCREEN / 2);
        [_loading startAnimating];
        _loading.hidesWhenStopped = YES;
    }
    return _loading;
}

- (UIImageView *)bgView{
    if (!_bgView) {
        _bgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bg.png"]];
        _bgView.frame = SCREEN_RECT;
    }
    return _bgView;
}
/***************************************小说部分************************************************/
- (void)setupNovel{
    self.title = @"书架";
    
    [self.view addSubview:self.tableView];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"nav_searchBtn"] style:UIBarButtonItemStylePlain target:self action:@selector(gotoSearchController)];
    
    [self.tableView registerClass:[RXBookshelfCell class] forCellReuseIdentifier:cellIdentifier];
    
    self.bookShelfArray = [self getDataSource];
    
    [self.tableView reloadData];
    
    [RXNotificationCenter addObserver:self selector:@selector(bookShelfChanged) name:RXBookShelfNotification object:nil];
}

#pragma mark - 数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.bookShelfArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    RXBookDetailModel *model = [self.bookShelfArray rx_objectAtIndex:indexPath.row];
    
    RXBookshelfCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    cell.mode = model;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    RXWeakSelf(self);
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"转码" message:@"您将查看的本小说内容由第三方网站提供，本软件仅提供技术转码服务，以便给您更好的阅读体验，如有侵权，请联系我们进行屏蔽" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:nil];
    
    UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"继续阅读" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [[RXReadUtilites sharedInstance] resetInstance];
        RXBookDetailModel *model = [self.bookShelfArray rx_objectAtIndex:indexPath.row];
        RXReadViewController *readVc = [[RXReadViewController alloc] init];
        readVc.bookId = model.ID;
        [weakself presentViewController:readVc animated:YES completion:nil];
    }];
    
    [alert addAction:action];
    [alert addAction:action1];
    [self presentViewController:alert animated:YES completion:nil];
    
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        RXBookDetailModel *bookModel = [self.bookShelfArray rx_objectAtIndex:indexPath.row];
        NSMutableArray *tempArray = [NSMutableArray arrayWithArray:[RXReadUtilites getBookshelfsBook]];
        for (NSMutableDictionary *dict in self.bookDictArray) {
            if ([dict[@"_id"] isEqualToString:bookModel.ID]) {
                [tempArray removeObject:dict];
                [RXReadUtilites saveBookToShelfsBookWithBookArray:tempArray];
                [self bookShelfChanged];
                break;
            }
        }
    }
}

- (void)bookShelfChanged{
    self.bookShelfArray = [self getDataSource];
    
    [self.tableView reloadData];
}

- (void)gotoSearchController{
    RXSearchController *searchVc = [[RXSearchController alloc] init];
    searchVc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:searchVc animated:YES];
}

- (void)dealloc{
    [RXNotificationCenter removeObserver:self];
}
- (RXTableView *)tableView {
    if (!_tableView) {
        RXTableView *tableView = [[RXTableView alloc] initWithFrame:self.view.bounds];
        [tableView setBackgroundColor:[UIColor whiteColor]];
        tableView.delegate = self;
        tableView.rowHeight = 120;
        tableView.dataSource = self;
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
        [self.view addSubview:tableView];
        _tableView = tableView;
    }
    return _tableView;
}

- (NSMutableArray *)bookShelfArray{
    if (!_bookShelfArray) {
        _bookShelfArray = [NSMutableArray array];
    }
    return _bookShelfArray;
}

- (NSMutableArray *)bookDictArray{
    if (!_bookDictArray) {
        _bookDictArray = [NSMutableArray array];
    }
    return _bookDictArray;
}
- (NSMutableArray *)getDataSource{
    NSMutableArray *tempArray = [RXReadUtilites getBookshelfsBook];
    self.bookDictArray = tempArray;
    NSMutableArray *modelArray = [RXBookDetailModel mj_objectArrayWithKeyValuesArray:tempArray];
    return modelArray;
}
@end
