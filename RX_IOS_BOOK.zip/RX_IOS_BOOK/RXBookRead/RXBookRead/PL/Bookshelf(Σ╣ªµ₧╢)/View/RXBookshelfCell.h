//
//  RXBookshelfCell.h
//  RXBookRead
//
//  Created by Evan on 2018/6/12.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXTableViewCell.h"
#import "RXBookDetailModel.h"

@interface RXBookshelfCell : RXTableViewCell
@property (nonatomic, strong) RXBookDetailModel *mode;
@end
