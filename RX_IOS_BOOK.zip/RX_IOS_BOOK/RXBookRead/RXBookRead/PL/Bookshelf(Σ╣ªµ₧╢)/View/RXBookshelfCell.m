//
//  RXBookshelfCell.m
//  RXBookRead
//
//  Created by Evan on 2018/6/12.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXBookshelfCell.h"
#import "RXReadUtilites.h"
#import "RXChapterModel.h"

@interface RXBookshelfCell()
@property (nonatomic, weak) UIImageView *iconView;

@property (nonatomic, weak) UILabel *titleLabel;

@property (nonatomic, weak) UILabel *authoLabel;

@property (nonatomic, weak) UILabel *stateLabel;
@end

@implementation RXBookshelfCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        [self setupUI];
    }
    return self;
}

- (void)setMode:(RXBookDetailModel *)mode{
    _mode = mode;
    
    //图片
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",IMAGE_PRE,mode.cover]];
    [self.iconView sd_setImageWithURL:url];
    
    //标题
    self.titleLabel.text = mode.title;
    
    //作者
    self.authoLabel.text = mode.author;
    NSMutableDictionary *dict = [RXReadUtilites getDownLoadedChapter:mode.ID];
    if (dict) {
        NSString *title = ((RXChapterModel *)[dict[@"allChapterListModel"] rx_objectAtIndex:[dict[@"currentChapter"] integerValue] - 1]).title;
        //状态
        self.stateLabel.text = [NSString stringWithFormat:@"已读至:%@",title];
    }
    
}

- (void)setupUI{
    
    //图片
    UIImageView *iconView = [[UIImageView alloc] init];
    [self.contentView addSubview:iconView];
    self.iconView = iconView;
    
    //标题
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.font = [UIFont systemFontOfSize:15];
    titleLabel.textColor = [UIColor blackColor];
    [self.contentView addSubview:titleLabel];
    self.titleLabel = titleLabel;
    //作者
    UILabel *authoLabel = [[UILabel alloc] init];
    authoLabel.font = [UIFont systemFontOfSize:12];
    authoLabel.textColor = [UIColor lightGrayColor];
    [self.contentView addSubview:authoLabel];
    self.authoLabel = authoLabel;
    //看书的状态
    UILabel *stateLabel = [[UILabel alloc] init];
    stateLabel.font = [UIFont systemFontOfSize:12];
    stateLabel.textColor = RXColor(200, 10, 10, 1.0);
    [self.contentView addSubview:stateLabel];
    self.stateLabel = stateLabel;
    
    [self setConstraints];
}

- (void)setConstraints{
    [self.iconView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView).offset(20);
        make.top.equalTo(self.contentView).offset(20);
        make.size.mas_equalTo(CGSizeMake(60, 80));
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.iconView.mas_right).offset(20);
        make.top.equalTo(self.iconView).offset(5);
        make.right.equalTo(self.contentView).offset(-30);
    }];
    
    [self.authoLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.iconView.mas_right).offset(20);
        make.top.equalTo(self.titleLabel.mas_bottom).offset(10);
        make.right.equalTo(self.contentView).offset(-30);
    }];
    
    [self.stateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.iconView.mas_right).offset(20);
        make.top.equalTo(self.authoLabel.mas_bottom).offset(10);
        make.right.equalTo(self.contentView).offset(-30);
    }];
}
@end
