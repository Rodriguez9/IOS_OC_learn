//
//  RXSearchResultController.m
//  RXBookRead
//
//  Created by Evan on 2018/6/2.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXSearchResultController.h"
#import "RXLeaderContentModel.h"
#import "RXBookDetailController.h"
#import "RXLeaderContentCell.h"

#define cellIdentifier @"searchResultCell"
@interface RXSearchResultController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic, weak) RXTableView *tableView;

@property (nonatomic, strong) NSArray *bookList;
@end

@implementation RXSearchResultController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    [self.view addSubview:self.tableView];
    
    [self.tableView registerClass:[RXLeaderContentCell class] forCellReuseIdentifier:cellIdentifier];
    
    [self loadData];
}

- (void)loadData{
    RXWeakSelf(self);
    [RXAPIManager getSearchResultWithKeyword:self.keyword success:^(RXLeaderContentModel *categoryBookModel) {
        weakself.bookList = categoryBookModel.books;
        [weakself.tableView reloadData];
    } failure:^(NSError *error) {
        
    }];
}
#pragma mark - 数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.bookList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    RXLeaderContentDetailModel *leaderContentModel = [self.bookList rx_objectAtIndex:indexPath.row];
    
    RXLeaderContentCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    cell.leaderContentModel = leaderContentModel;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    RXLeaderContentDetailModel *leaderContentModel = [self.bookList rx_objectAtIndex:indexPath.row];
    RXBookDetailController *bookDetailVc = [[RXBookDetailController alloc] init];
    bookDetailVc.bookId = leaderContentModel.ID;
    [self.navigationController pushViewController:bookDetailVc animated:YES];
}
- (RXTableView *)tableView {
    if (!_tableView) {
        RXTableView *tableView = [[RXTableView alloc] initWithFrame:self.view.bounds];
        [tableView setBackgroundColor:[UIColor whiteColor]];
        tableView.delegate = self;
        tableView.rowHeight = 110;
        tableView.dataSource = self;
        [tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
        [self.view addSubview:tableView];
        _tableView = tableView;
    }
    return _tableView;
}
@end
