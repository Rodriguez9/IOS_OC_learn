//
//  RXSearchController.m
//  RXBookRead
//
//  Created by Evan on 2018/5/29.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXSearchController.h"
#import "RXSearchView.h"
#import "RXSearchHotwordModel.h"
#import "RXSearchResultController.h"

@interface RXSearchController ()<UISearchBarDelegate>
@property (nonatomic, weak) UISearchBar *searchBar;
@property (nonatomic, strong) NSMutableArray *hotArray;
@property (nonatomic, strong) NSMutableArray *historyArray;
@property (nonatomic, strong) RXSearchView *searchView;
@end

@implementation RXSearchController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"搜索";
    self.view.backgroundColor = [UIColor whiteColor];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dissMissKeyBoard)];
    [self.view addGestureRecognizer:tap];
    
    [self setBarButtonItem];
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
      [self loadData];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self dissMissKeyBoard];
}
- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    
    [self.searchView removeFromSuperview];
    self.searchView = nil;
}

- (void)dissMissKeyBoard{
    [self.searchBar resignFirstResponder];
}

- (void)loadData{
    RXWeakSelf(self);
    [RXAPIManager getSearchHotwordSuccess:^(RXSearchHotwordModel *searchHotwordModel) {
        dispatch_async(dispatch_get_main_queue(), ^{
             weakself.hotArray = searchHotwordModel.hotWords;
            [weakself.view addSubview:weakself.searchView];
            weakself.searchView.historyArray = weakself.historyArray;
            [weakself.searchView setTapAction:^(NSString *keyword) {
                [weakself.searchBar resignFirstResponder];
                [weakself pushToSearchResultWithSearchStr:keyword];
            }];
        });
       
    } failure:^(NSError *error) {
        
    }];
}
- (void)setBarButtonItem
{
    // 创建搜索框
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectMake(5, 7, self.view.frame.size.width, 26)];
    titleView.backgroundColor = [UIColor clearColor];
    UISearchBar *searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(titleView.frame) - 15, 26)];
    [searchBar setBackgroundImage:[UIImage new]];
    searchBar.backgroundColor = [UIColor clearColor];
    searchBar.placeholder = @"请输入小说名";
    searchBar.delegate = self;
    searchBar.showsCancelButton = YES;
    UITextField *searchTextField = [searchBar valueForKey:@"_searchField"];
    searchTextField.backgroundColor = [UIColor whiteColor];
    [searchTextField setValue:[UIFont boldSystemFontOfSize:13] forKeyPath:@"_placeholderLabel.font"];
    searchTextField.layer.cornerRadius = 4;
    searchTextField.layer.masksToBounds = YES;
    UIButton *cancleBtn = [searchBar valueForKey:@"cancelButton"];
    //修改标题和标题颜色
    [cancleBtn setTitle:@"取消" forState:UIControlStateNormal];
    [cancleBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [titleView addSubview:searchBar];
    self.searchBar = searchBar;
    [self.searchBar becomeFirstResponder];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] init];
    self.navigationItem.titleView = titleView;
}

#pragma mark - 搜索框代理方法
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    [self.searchBar resignFirstResponder];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    [self.searchBar resignFirstResponder];
    [self pushToSearchResultWithSearchStr:searchBar.text];
}

- (void)pushToSearchResultWithSearchStr:(NSString *)str
{
    RXSearchResultController *searchResultVc = [[RXSearchResultController alloc] init];
    searchResultVc.keyword = str;
    searchResultVc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:searchResultVc animated:YES];
    [self setHistoryArrWithStr:str];
}
//把搜索关键词加入历史记录
- (void)setHistoryArrWithStr:(NSString *)str
{
    for (int i = 0; i < _historyArray.count; i++) {
        if ([[_historyArray rx_objectAtIndex:i] isEqualToString:str]) {
            [_historyArray removeObjectAtIndex:i];
            break;
        }
    }
    [self.historyArray rx_insertObject:str atIndex:0];
    NSString *path = [RXDocumentDirectory stringByAppendingString:@"searchHistory.plist"];
    [NSKeyedArchiver archiveRootObject:_historyArray toFile:path];
}

- (RXSearchView *)searchView{
    if (!_searchView) {
        _searchView = [[RXSearchView alloc] initWithFrame:CGRectMake(0, HEIGHT_NAV_FIT, WIDTH_SCREEN, HEIGHT_SCREEN - HEIGHT_NAV_FIT) hotArray:self.hotArray];
    }
    return _searchView;
}
- (NSMutableArray *)hotArray
{
    if (!_hotArray) {
        self.hotArray = [NSMutableArray array];
    }
    return _hotArray;
}

- (NSMutableArray *)historyArray
{
    if (!_historyArray) {
        NSString *path = [RXDocumentDirectory stringByAppendingString:@"searchHistory.plist"];
        _historyArray = [NSKeyedUnarchiver unarchiveObjectWithFile:path];
        if (!_historyArray) {
            self.historyArray = [NSMutableArray array];
        }
    }
    return _historyArray;
}
@end
