//
//  RXSearchResultController.h
//  RXBookRead
//
//  Created by Evan on 2018/6/2.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXBaseController.h"

@interface RXSearchResultController : RXBaseController
@property (nonatomic, copy) NSString *keyword;
@end
