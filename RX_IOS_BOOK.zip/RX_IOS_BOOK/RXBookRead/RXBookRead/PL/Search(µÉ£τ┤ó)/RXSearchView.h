//
//  RXSearchView.h
//  RXBookRead
//
//  Created by Evan on 2018/6/1.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RXSearchView : UIView
@property (nonatomic, strong) NSMutableArray *historyArray;
@property (nonatomic, copy) void(^tapAction)(NSString *keyword);
- (instancetype)initWithFrame:(CGRect)frame hotArray:(NSMutableArray *)hotArr;
@end
