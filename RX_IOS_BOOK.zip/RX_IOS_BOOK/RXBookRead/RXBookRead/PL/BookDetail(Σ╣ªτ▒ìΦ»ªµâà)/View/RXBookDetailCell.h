//
//  RXBookDetailCell.h
//  RXBookRead
//
//  Created by Evan on 2018/5/31.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXTableViewCell.h"

@class RXBookDetailModel;
@interface RXBookDetailCell : RXTableViewCell
@property (nonatomic, strong) RXBookDetailModel *bookDetailModel;
@end
