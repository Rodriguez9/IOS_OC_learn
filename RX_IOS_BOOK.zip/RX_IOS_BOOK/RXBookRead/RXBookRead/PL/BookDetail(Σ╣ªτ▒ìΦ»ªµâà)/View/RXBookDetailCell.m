//
//  RXBookDetailCell.m
//  RXBookRead
//
//  Created by Evan on 1518/5/31.
//  Copyright © 1518年 Evan. All rights reserved.
//

#import "RXBookDetailCell.h"
#import "RXBookDetailModel.h"

@interface RXBookDetailCell()
@property (nonatomic, weak) UIImageView *iconView;

@property (nonatomic, weak) UILabel *titleLabel;

@property (nonatomic, weak) UILabel *authorLabel;

@property (nonatomic, weak) UILabel *majorCateLabel;

@property (nonatomic, weak) UILabel *bookStateLabel;

@property (nonatomic, weak) UILabel *updateChapterLabel;

@property (nonatomic, weak) UILabel *updateTimeLabel;

@property (nonatomic, weak) UILabel *introductLabel;
@end

@implementation RXBookDetailCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        [self setupUI];
    }
    return self;
}

- (void)setBookDetailModel:(RXBookDetailModel *)bookDetailModel{
    _bookDetailModel = bookDetailModel;
    
    //图片
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",IMAGE_PRE,bookDetailModel.cover]];
    [self.iconView sd_setImageWithURL:url];
    
    //标题
    self.titleLabel.text = bookDetailModel.title;
    
    //作者
    self.authorLabel.text = bookDetailModel.author;
    
    //类型
    self.majorCateLabel.text = bookDetailModel.majorCate;
    
    //书籍状态
    if (bookDetailModel.majorCate) {
        self.bookStateLabel.text = bookDetailModel.isSerial ? @"未完结" : @"完结";
    }
    
    //更新章节
    if (bookDetailModel.lastChapter) {
       self.updateChapterLabel.text = [NSString stringWithFormat:@"最新章节:%@",bookDetailModel.lastChapter];
    }
    
    //更新时间
    if (bookDetailModel.updateTime) {
       self.updateTimeLabel.text = [NSString stringWithFormat:@"更新时间:%@",bookDetailModel.updateTime];
    }
    
    //介绍
    if (bookDetailModel.longIntro) {
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:bookDetailModel.longIntro];
        NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
        [paragraphStyle setLineSpacing:5];
        [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, [bookDetailModel.longIntro length])];
        self.introductLabel.attributedText = attributedString;
    }
   
    [self.contentView setNeedsLayout];
    [self.contentView layoutIfNeeded];

    self.bookDetailModel.cellHeight = self.introductLabel.mp_y + self.introductLabel.mp_height;
    
}
- (void)setupUI{
    //图片
    UIImageView *iconView = [[UIImageView alloc] init];
    [self.contentView addSubview:iconView];
    self.iconView = iconView;
    
    //标题
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.font = [UIFont systemFontOfSize:13];
    titleLabel.textColor = [UIColor blackColor];
    [self.contentView addSubview:titleLabel];
    self.titleLabel = titleLabel;
    
    //作者
    UILabel *authorLabel = [[UILabel alloc] init];
    [self setupUIWithLabel:authorLabel];
    self.authorLabel= authorLabel;
    
    //类型
    UILabel *majorCateLabel = [[UILabel alloc] init];
    [self setupUIWithLabel:majorCateLabel];
    self.majorCateLabel= majorCateLabel;
    
    //状态
    UILabel *bookStateLabel = [[UILabel alloc] init];
    [self setupUIWithLabel:bookStateLabel];
    self.bookStateLabel= bookStateLabel;
    
    //更新章节
    UILabel *updateChapterLabel = [[UILabel alloc] init];
    [self setupUIWithLabel:updateChapterLabel];
    self.updateChapterLabel= updateChapterLabel;
    
    //更新时间
    UILabel *updateTimeLabel = [[UILabel alloc] init];
   [self setupUIWithLabel:updateTimeLabel];
    self.updateTimeLabel= updateTimeLabel;
    
    //介绍
    UILabel *introductLabel = [[UILabel alloc] init];
    introductLabel.font = [UIFont systemFontOfSize:12];
    introductLabel.textColor = [UIColor blackColor];
    introductLabel.numberOfLines = 0;
    [self.contentView addSubview:introductLabel];
    self.introductLabel= introductLabel;
    
    [self setConstraints];
}

- (void)setConstraints{
    [self.iconView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView).offset(15);
        make.top.equalTo(self.contentView).offset(15);
        make.size.mas_equalTo(CGSizeMake(80, 100));
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.iconView.mas_right).offset(15);
        make.top.equalTo(self.contentView).offset(15);
        make.right.equalTo(self.contentView).offset(-15);
    }];
    
    [self.authorLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.iconView.mas_right).offset(15);
        make.right.equalTo(self.contentView).offset(-15);
        make.top.equalTo(self.titleLabel.mas_bottom).offset(5);
    }];
    
    [self.majorCateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.iconView.mas_right).offset(15);
        make.right.equalTo(self.contentView).offset(-15);
        make.top.equalTo(self.authorLabel.mas_bottom).offset(5);
    }];
    
    [self.bookStateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.iconView.mas_right).offset(15);
        make.right.equalTo(self.contentView).offset(-15);
        make.top.equalTo(self.majorCateLabel.mas_bottom).offset(5);
    }];
    
    [self.updateChapterLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.iconView.mas_right).offset(15);
        make.right.equalTo(self.contentView).offset(-15);
        make.top.equalTo(self.bookStateLabel.mas_bottom).offset(5);
    }];
    
    [self.updateTimeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.iconView.mas_right).offset(15);
        make.right.equalTo(self.contentView).offset(-15);
        make.top.equalTo(self.updateChapterLabel.mas_bottom).offset(5);
    }];
    
    [self.introductLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.iconView.mas_bottom).offset(8);
        make.left.equalTo(self.contentView).offset(15);
        make.right.equalTo(self.contentView).offset(-15);
    }];
    
}
- (void)setupUIWithLabel:(UILabel *)label{
    label.font = [UIFont systemFontOfSize:10];
    label.textColor = [UIColor darkGrayColor];
    [self.contentView addSubview:label];
}
@end
