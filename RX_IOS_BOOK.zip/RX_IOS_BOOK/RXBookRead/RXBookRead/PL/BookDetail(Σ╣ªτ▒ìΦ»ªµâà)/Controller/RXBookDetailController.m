//
//  RXBookDetailController.m
//  RXBookRead
//
//  Created by Evan on 2018/5/31.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXBookDetailController.h"
#import "RXBookDetailCell.h"
#import "RXReadViewController.h"
#import "RXReadUtilites.h"

#define cellIdentifier @"bookDetailCell"
@interface RXBookDetailController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic, weak) RXTableView *tableView;

@property (nonatomic, weak) UIButton *bookshelfButton;

@property (nonatomic, weak) UIButton *readButton;

@property (nonatomic, strong) NSMutableArray *bookShelfArray;
@end

@implementation RXBookDetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"书单详情";
   
    self.bookShelfArray = [NSMutableArray arrayWithArray:[RXReadUtilites getBookshelfsBook]];
    
    [self setupUI];
    
    [self loadData];
}

- (void)setupUI{
    [self.view addSubview:self.tableView];
    
    [self.tableView registerClass:[RXBookDetailCell class] forCellReuseIdentifier:cellIdentifier];
    
    //加入书架
    UIButton *bookshelfButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [bookshelfButton setTitle:@"放入书架" forState:UIControlStateNormal];
    for (NSMutableDictionary *tempDict in self.bookShelfArray) {
        if ([tempDict[@"_id"] isEqualToString:self.bookId]) {
             [bookshelfButton setTitle:@"移出书架" forState:UIControlStateNormal];
            break;
        }
    }
    [bookshelfButton setBackgroundColor:[UIColor whiteColor]];
    [bookshelfButton setTitleColor:RXColor(200, 10, 10, 1.0) forState:UIControlStateNormal];
     [bookshelfButton addTarget:self action:@selector(addBookToBookShelf) forControlEvents:UIControlEventTouchDown];
    [self.view addSubview:bookshelfButton];
    self.bookshelfButton = bookshelfButton;
    
    //立即阅读
    UIButton *readButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [readButton setBackgroundColor:RXColor(200, 10, 10, 1.0)];
    [readButton setTitle:@"立即阅读" forState:UIControlStateNormal];
    [readButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [readButton addTarget:self action:@selector(readBook) forControlEvents:UIControlEventTouchDown];
    [self.view addSubview:readButton];
    self.readButton = readButton;
    
    [self.bookshelfButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.equalTo(self.view);
        make.width.mas_equalTo(WIDTH_SCREEN / 2);
        make.height.mas_equalTo(48 + HEIGHT_VIRTUAL_FIT);
    }];
    
    [self.readButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.bottom.equalTo(self.view);
        make.width.mas_equalTo(WIDTH_SCREEN / 2);
        make.height.mas_equalTo(48 + HEIGHT_VIRTUAL_FIT);
    }];
    
}
#pragma maek - 加载数据
- (void)loadData{
    RXWeakSelf(self);
    [RXAPIManager getBookDetailWithBookId:self.bookId success:^(RXBookDetailModel *bookDetailModel) {
        weakself.bookDetailModel = bookDetailModel;
        [weakself.tableView reloadData];
    } failure:^(NSError *error) {
        
    }];
}

#pragma mark - 数据源方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    RXBookDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    cell.bookDetailModel = self.bookDetailModel;
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return self.bookDetailModel.cellHeight + 8;
}

//立即阅读
- (void)readBook{
    RXWeakSelf(self);
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"转码" message:@"您将查看的本小说内容由第三方网站提供，本软件仅提供技术转码服务，以便给您更好的阅读体验，如有侵权，请联系我们进行屏蔽" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:nil];
    
    UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"继续阅读" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [[RXReadUtilites sharedInstance] resetInstance];
        RXReadViewController *readVc = [[RXReadViewController alloc] init];
        readVc.bookId = self.bookId;
        [weakself presentViewController:readVc animated:YES completion:nil];
    }];
    
    [alert addAction:action];
    [alert addAction:action1];
    [self presentViewController:alert animated:YES completion:nil];
   
}

//加入书架
- (void)addBookToBookShelf{
    if ([self.bookshelfButton.titleLabel.text isEqualToString:@"放入书架"]) {
         [self.bookshelfButton setTitle:@"移出书架" forState:UIControlStateNormal];
        //没加入过书架
        NSMutableDictionary *dict = [NSMutableDictionary dictionary];
        [dict rx_setObject:self.bookId forKey:@"_id"];
        [dict rx_setObject:self.bookDetailModel.title forKey:@"title"];
        [dict rx_setObject:self.bookDetailModel.cover forKey:@"cover"];
        [dict rx_setObject:self.bookDetailModel.author forKey:@"author"];
        [self.bookShelfArray addObject:dict];
        [RXReadUtilites saveBookToShelfsBookWithBookArray:self.bookShelfArray];
        [SVProgressHUD showSuccessWithStatus:@"已放入书架"];
         [SVProgressHUD dismissWithDelay:0.5];
    }else{
        [self.bookshelfButton setTitle:@"放入书架" forState:UIControlStateNormal];
        NSMutableArray *tempArray = [NSMutableArray arrayWithArray:self.bookShelfArray];
        for (NSMutableDictionary *tempDict in self.bookShelfArray) {
            if ([tempDict[@"_id"] isEqualToString:self.bookDetailModel.ID]) {
                //说明已经加入过书架
                [tempArray removeObject:tempDict];
                self.bookShelfArray = tempArray;
                [RXReadUtilites saveBookToShelfsBookWithBookArray:tempArray];
                 [SVProgressHUD showSuccessWithStatus:@"已移出书架"];
                [SVProgressHUD dismissWithDelay:0.5];
                break;
            }
        }

    }
    
    [RXNotificationCenter postNotificationName:RXBookShelfNotification object:nil];
}

- (RXTableView *)tableView {
    if (!_tableView) {
        RXTableView *tableView = [[RXTableView alloc] initWithFrame:CGRectMake(0, 0, WIDTH_SCREEN, self.view.bounds.size.height- 48 - HEIGHT_VIRTUAL_FIT)];
        [tableView setBackgroundColor:RXHexColor(@"eeeeee")];
        tableView.delegate = self;
        tableView.dataSource = self;
        [self.view addSubview:tableView];
        _tableView = tableView;
    }
    return _tableView;
}
@end
