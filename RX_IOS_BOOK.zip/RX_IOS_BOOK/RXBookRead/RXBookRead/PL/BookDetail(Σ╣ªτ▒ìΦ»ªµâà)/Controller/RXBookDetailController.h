//
//  RXBookDetailController.h
//  RXBookRead
//
//  Created by Evan on 2018/5/31.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "RXBaseController.h"
#import "RXBookDetailModel.h"

@interface RXBookDetailController : RXBaseController
@property (nonatomic, strong) RXBookDetailModel *bookDetailModel;
@property (nonatomic, copy) NSString *bookId;
@end
