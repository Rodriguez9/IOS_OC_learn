//
//  AppDelegate.m
//  RXBookRead
//
//  Created by Evan on 2018/5/28.
//  Copyright © 2018年 Evan. All rights reserved.
//

#import "AppDelegate.h"
#import "RXTabBarController.h"
#import "GDTSDKConfig.h"


@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    [UIApplication sharedApplication].idleTimerDisabled=YES;
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    self.window.backgroundColor = [UIColor whiteColor];
    
    self.window.rootViewController = [[RXTabBarController alloc] init];
    
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    
    [UIApplication sharedApplication].statusBarHidden = YES;
    
    [self.window makeKeyAndVisible];
    
//    //开屏广告初始化并展示代码
//    [GDTSDKConfig setHttpsOn];
//    
//    GDTSplashAd *splash = [[GDTSplashAd alloc] initWithAppId:AppId placementId:PlacementId];
//    
//    splash.backgroundColor = [UIColor colorWithPatternImage:[RXUtilites getBackgroundImage]];
//    
//    splash.delegate = self;
//    
//    splash.fetchDelay = 3;
//    
//    [splash loadAdAndShowInWindow:self.window];
//    
//    self.splash = splash;
    
    return YES;
}

- (void)splashAdApplicationWillEnterBackground:(GDTSplashAd *)splashAd
{
    NSLog(@"%s",__FUNCTION__);
}
//开屏广告成功展示
-(void)splashAdSuccessPresentScreen:(GDTSplashAd *)splashAd
{
    NSLog(@"%s",__FUNCTION__);
}
//开屏广告展示失败
-(void)splashAdFailToPresent:(GDTSplashAd *)splashAd withError:(NSError *)error
{
    NSLog(@"%s%@",__FUNCTION__,error);
    self.splash = nil;
}

- (void)splashAdWillClosed:(GDTSplashAd *)splashAd
{
    NSLog(@"%s",__FUNCTION__);
}
//点击了关闭开屏广告
-(void)splashAdClosed:(GDTSplashAd *)splashAd
{
    NSLog(@"%s",__FUNCTION__);
    self.splash = nil;
}

- (void)splashAdWillPresentFullScreenModal:(GDTSplashAd *)splashAd
{
    NSLog(@"%s",__FUNCTION__);
}

- (void)splashAdDidPresentFullScreenModal:(GDTSplashAd *)splashAd
{
    NSLog(@"%s",__FUNCTION__);
}

- (void)splashAdExposured:(GDTSplashAd *)splashAd
{
    NSLog(@"%s",__FUNCTION__);
}
//点击了开屏广告
- (void)splashAdClicked:(GDTSplashAd *)splashAd
{
    NSLog(@"%s",__FUNCTION__);
}

- (void)splashAdWillDismissFullScreenModal:(GDTSplashAd *)splashAd
{
    NSLog(@"%s",__FUNCTION__);
}

- (void)splashAdDidDismissFullScreenModal:(GDTSplashAd *)splashAd
{
    NSLog(@"%s",__FUNCTION__);
}
@end
